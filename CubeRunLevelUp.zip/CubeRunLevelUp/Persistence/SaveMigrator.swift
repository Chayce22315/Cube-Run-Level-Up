import Foundation

class SaveMigrator {
    static func migrateIfNeeded(state: inout GameState) {
        // v1 is current; no migration needed yet
        state.saveVersion = CURRENT_SAVE_VERSION
    }
}
