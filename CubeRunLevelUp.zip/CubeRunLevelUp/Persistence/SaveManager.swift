import Foundation
import CryptoKit

class SaveManager {
    static let shared = SaveManager()
    private init() {}

    private var docsDir: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
    private var currentURL: URL { docsDir.appendingPathComponent("save_current.json") }
    private var backup1URL: URL { docsDir.appendingPathComponent("save_backup1.json") }
    private var backup2URL: URL { docsDir.appendingPathComponent("save_backup2.json") }

    private var timer: Timer?

    func startAutoSave(every seconds: Double, engine: GameEngine) {
        timer?.invalidate()
        timer = Timer.scheduledTimer(withTimeInterval: seconds, repeats: true) { _ in
            self.save(state: engine.state)
        }
    }

    func stopAutoSave() {
        timer?.invalidate()
        timer = nil
    }

    func save(state: GameState) {
        do {
            let encoded = try JSONEncoder().encode(state)
            let checksum = encoded.sha256Hex
            let saveFile = SaveFile(state: state, checksum: checksum, writtenAt: Date())
            let payload = try JSONEncoder().encode(saveFile)

            try? FileManager.default.removeItem(at: backup2URL)
            try? FileManager.default.moveItem(at: backup1URL, to: backup2URL)
            try? FileManager.default.moveItem(at: currentURL, to: backup1URL)

            let tempURL = currentURL.appendingPathExtension("tmp")
            try payload.write(to: tempURL, options: .atomic)
            try FileManager.default.moveItem(at: tempURL, to: currentURL)
        } catch {
            ErrorReportingService.shared.log(ErrorLogEntry(
                id: UUID(), severity: .warning, message: "Save failed: \(error.localizedDescription)",
                context: "SaveManager", timestamp: Date(), stackSummary: nil
            ))
        }
    }

    func load() -> GameState {
        if let state = tryLoad(currentURL) { return state }
        if let state = tryLoad(backup1URL) { return state }
        if let state = tryLoad(backup2URL) { return state }
        return GameState.new()
    }

    private func tryLoad(_ url: URL) -> GameState? {
        guard let data = try? Data(contentsOf: url),
              let saveFile = try? JSONDecoder().decode(SaveFile.self, from: data) else { return nil }
        guard let stateData = try? JSONEncoder().encode(saveFile.state),
              saveFile.checksum == stateData.sha256Hex else { return nil }
        return saveFile.state
    }
}
