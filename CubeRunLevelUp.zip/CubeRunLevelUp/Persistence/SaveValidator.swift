import Foundation

class SaveValidator {
    static func validate(_ state: GameState) -> Bool {
        state.level >= 1 && state.currentHP >= 0 && state.distance >= 0
    }
}
