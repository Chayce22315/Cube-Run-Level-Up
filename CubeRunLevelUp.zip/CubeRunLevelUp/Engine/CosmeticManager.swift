import Foundation

class CosmeticManager {
    func activeSetBonus(state: GameState) -> (stat: StatType, value: Int) {
        let skinTheme = theme(for: state.equippedCosmetics.skin)
        let trailTheme = theme(for: state.equippedCosmetics.trail)
        let auraTheme = theme(for: state.equippedCosmetics.aura)

        if let theme = skinTheme, theme == trailTheme && theme == auraTheme {
            return theme.setBonus
        }
        return (.strength, 0)
    }

    private func theme(for cosmetic: CosmeticID) -> CosmeticTheme? {
        switch cosmetic {
        case .skinLava, .trailFire, .auraRedGlow: return .lava
        case .skinCrystal, .trailIce, .auraPurpleGlow: return .crystal
        case .skinShadow, .trailSmoke, .auraPurpleGlow: return .shadow
        case .skinGold, .trailFire, .auraGoldGlow: return .gold
        case .skinRainbow, .trailRainbow, .auraHoly: return .rainbow
        case .skinVoid, .trailVoid, .auraHoly: return .void
        default: return nil
        }
    }

    func checkUnlocks(state: inout GameState) {
        // Skins
        if state.bossesDefeated >= 10 { state.unlockedCosmetics.insert(.skinLava) }
        if state.level >= 40 { state.unlockedCosmetics.insert(.skinCrystal) }
        if state.prestigeCount >= 3 { state.unlockedCosmetics.insert(.skinShadow) }
        if state.totalCoinsEarned >= 10_000_000 { state.unlockedCosmetics.insert(.skinGold) }
        if state.unlockedAchievements.count >= 20 { state.unlockedCosmetics.insert(.skinRainbow) }
        if state.prestigeCount >= 25 { state.unlockedCosmetics.insert(.skinVoid) }

        // Trails
        if state.unlockedCosmetics.contains(.skinLava) { state.unlockedCosmetics.insert(.trailFire) }
        if state.level >= 60 { state.unlockedCosmetics.insert(.trailIce) }
        // Star trail: 20 weekly quests lifetime — not tracked precisely, skip for v1
        if state.bossesDefeated >= 100 { state.unlockedCosmetics.insert(.trailSmoke) }
        if state.unlockedCosmetics.contains(.skinRainbow) { state.unlockedCosmetics.insert(.trailRainbow) }
        if state.unlockedCosmetics.contains(.skinVoid) { state.unlockedCosmetics.insert(.trailVoid) }

        // Auras
        if state.unlockedAchievements.contains(.wealth4) { state.unlockedCosmetics.insert(.auraGoldGlow) }
        if state.level >= 80 { state.unlockedCosmetics.insert(.auraPurpleGlow) }
        if state.unlockedAchievements.contains(.bosses5) { state.unlockedCosmetics.insert(.auraRedGlow) }
        if state.prestigeCount >= 10 { state.unlockedCosmetics.insert(.auraLightning) }
        if state.unlockedAchievements.contains(.survival4) { state.unlockedCosmetics.insert(.auraHoly) }

        // Effects
        if state.unlockedCosmetics.contains(.skinLava) { state.unlockedCosmetics.insert(.effectFire) }
        if state.unlockedCosmetics.contains(.skinCrystal) { state.unlockedCosmetics.insert(.effectIce) }
        if state.unlockedCosmetics.contains(.auraHoly) { state.unlockedCosmetics.insert(.effectHoly) }
        if state.unlockedCosmetics.contains(.skinVoid) { state.unlockedCosmetics.insert(.effectVoid) }

        // Titles
        if state.level >= 10 { state.unlockedCosmetics.insert(.titleRunner) }
        if state.bossesDefeated >= 25 { state.unlockedCosmetics.insert(.titleChampion) }
        if state.prestigeCount >= 10 { state.unlockedCosmetics.insert(.titleLegend) }
        if state.prestigeCount >= 50 { state.unlockedCosmetics.insert(.titleAscended) }
        if state.unlockedAchievements.contains(.completionist) { state.unlockedCosmetics.insert(.titleEternal) }
    }
}
