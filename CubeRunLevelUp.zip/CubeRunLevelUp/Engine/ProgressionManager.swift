import Foundation

class ProgressionManager {
    func xpRequired(for level: Int) -> Double {
        100 * pow(1.15, Double(level))
    }
}
