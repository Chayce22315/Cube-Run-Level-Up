import Foundation

class EquipmentGenerator {
    private let prefixes: [EquipmentRarity: [String]] = [
        .common: ["Worn", "Simple", "Tattered", "Plain"],
        .uncommon: ["Sturdy", "Polished", "Refined"],
        .rare: ["Gleaming", "Superior", "Enchanted"],
        .epic: ["Mythic", "Ancient", "Heroic"],
        .legendary: ["Ascended", "Eternal", "Divine"]
    ]

    private let nouns: [EquipmentSlot: [String]] = [
        .weapon: ["Blade", "Sword", "Axe", "Dagger"],
        .armor: ["Plate", "Vest", "Mail", "Cuirass"],
        .helmet: ["Cap", "Helm", "Crown", "Mask"],
        .boots: ["Boots", "Greaves", "Treads", "Walkers"],
        .accessory: ["Charm", "Ring", "Amulet", "Talisman"]
    ]

    func generate(playerLevel: Int, forceRarity: EquipmentRarity? = nil) -> Equipment {
        let slot = EquipmentSlot.allCases.randomElement()!
        let rarity = forceRarity ?? rollRarity()
        let itemLevel = max(1, playerLevel + Int.random(in: -2...2))
        let baseStat = StatType.allCases.randomElement()!
        let baseValue = Int(Double(itemLevel) * (2 + rarity.scoreMultiplier))

        var secondaryType: StatType? = nil
        var secondaryValue: Int? = nil
        if rarity == .rare || rarity == .epic || rarity == .legendary {
            var pool = StatType.allCases.filter { $0 != baseStat }
            secondaryType = pool.randomElement()
            secondaryValue = Int(Double(baseValue) * 0.4)
        }

        let prefix = prefixes[rarity]?.randomElement() ?? ""
        let noun = nouns[slot]?.randomElement() ?? "Item"
        let name = "\(prefix) \(noun)"

        return Equipment(
            id: UUID(),
            slot: slot,
            rarity: rarity,
            itemLevel: itemLevel,
            baseStatType: baseStat,
            baseStatValue: baseValue,
            secondaryStatType: secondaryType,
            secondaryStatValue: secondaryValue,
            name: name
        )
    }

    private func rollRarity() -> EquipmentRarity {
        let weights = EquipmentRarity.allCases.map { $0.dropWeight }
        let total = weights.reduce(0, +)
        let roll = Double.random(in: 0..<total)
        var cumulative = 0.0
        for (index, weight) in weights.enumerated() {
            cumulative += weight
            if roll < cumulative {
                return EquipmentRarity.allCases[index]
            }
        }
        return .common
    }
}
