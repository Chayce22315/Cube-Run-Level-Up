import Foundation

class PrestigeManager {
    func calculateSouls(state: GameState) -> Int64 {
        let levelComponent = Double(state.level) * 0.8
        let distanceComponent = state.distance / 200.0
        let bossComponent = Double(state.bossesDefeated) * 2.0
        return max(1, Int64((levelComponent + distanceComponent + bossComponent).rounded(.down)))
    }

    func applyPrestige(state: inout GameState) {
        let soulsGained = calculateSouls(state: state)
        state.souls += soulsGained
        state.prestigeCount += 1

        // Reset
        state.level = 1
        state.currentXP = 0
        state.distance = state.permanentBonuses.startingDistance
        state.stats = PlayerStats()
        state.unspentStatPoints = 0
        state.equippedItems = [:]
        state.inventory = []
        state.maxHP = 100
        state.currentHP = 100
        state.unlockedAbilities = []
        state.abilityCooldowns = [:]
        state.activeBoss = nil
        state.bossesDefeated = 0
        state.nextBossDistanceThreshold = 1000
        state.coins = 0
        state.activeMonster = nil
        state.isDead = false
        state.reviveCooldownEndsAt = nil
        state.incomingDamageMultiplier = 1.0
        state.incomingDamageMultiplierExpiresAt = nil
        state.outgoingDamageMultiplier = 1.0
        state.outgoingDamageMultiplierExpiresAt = nil
        state.attackSpeedMultiplier = 1.0
        state.attackSpeedMultiplierExpiresAt = nil
        state.vampiricTouchActiveUntil = nil
        state.cubeRageActiveUntil = nil
    }
}
