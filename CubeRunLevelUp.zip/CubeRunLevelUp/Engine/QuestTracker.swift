import Foundation

class QuestTracker {
    func recordTick(state: inout GameState) {
        refreshIfNeeded(state: &state)
    }

    func recordDistance(_ delta: Double, state: inout GameState) {
        for i in state.dailyQuests.indices where state.dailyQuests[i].definitionID == .runDistance && !state.dailyQuests[i].isClaimed {
            state.dailyQuests[i].currentProgress += delta
        }
        for i in state.weeklyQuests.indices where state.weeklyQuests[i].definitionID == .runDistance && !state.weeklyQuests[i].isClaimed {
            state.weeklyQuests[i].currentProgress += delta
        }
    }

    func recordMonsterKill(state: inout GameState) {
        incrementQuest(.defeatMonsters, state: &state)
    }

    func recordBossKill(state: inout GameState) {
        incrementQuest(.defeatBosses, state: &state)
    }

    func recordCoins(_ amount: Int64, state: inout GameState) {
        for i in state.dailyQuests.indices where state.dailyQuests[i].definitionID == .earnCoins && !state.dailyQuests[i].isClaimed {
            state.dailyQuests[i].currentProgress += Double(amount)
        }
        for i in state.weeklyQuests.indices where state.weeklyQuests[i].definitionID == .earnCoins && !state.weeklyQuests[i].isClaimed {
            state.weeklyQuests[i].currentProgress += Double(amount)
        }
    }

    func recordLevelUp(state: inout GameState) {
        incrementQuest(.levelUp, state: &state)
    }

    func recordAbilityUse(state: inout GameState) {
        incrementQuest(.useAbilities, state: &state)
    }

    func recordEquipItem(state: inout GameState) {
        incrementQuest(.equipItems, state: &state)
    }

    func recordPrestige(state: inout GameState) {
        incrementQuest(.prestigeOnce, state: &state)
    }

    func recordGemsCollected(_ amount: Int64, state: inout GameState) {
        for i in state.dailyQuests.indices where state.dailyQuests[i].definitionID == .collectGems && !state.dailyQuests[i].isClaimed {
            state.dailyQuests[i].currentProgress += Double(amount)
        }
        for i in state.weeklyQuests.indices where state.weeklyQuests[i].definitionID == .collectGems && !state.weeklyQuests[i].isClaimed {
            state.weeklyQuests[i].currentProgress += Double(amount)
        }
    }

    func recordDeath(state: inout GameState) {
        for i in state.dailyQuests.indices where state.dailyQuests[i].definitionID == .surviveNoDeath && !state.dailyQuests[i].isClaimed {
            state.dailyQuests[i].currentProgress = 0
        }
        for i in state.weeklyQuests.indices where state.weeklyQuests[i].definitionID == .surviveNoDeath && !state.weeklyQuests[i].isClaimed {
            state.weeklyQuests[i].currentProgress = 0
        }
    }

    private func incrementQuest(_ id: QuestDefinitionID, state: inout GameState) {
        for i in state.dailyQuests.indices where state.dailyQuests[i].definitionID == id && !state.dailyQuests[i].isClaimed {
            state.dailyQuests[i].currentProgress += 1
        }
        for i in state.weeklyQuests.indices where state.weeklyQuests[i].definitionID == id && !state.weeklyQuests[i].isClaimed {
            state.weeklyQuests[i].currentProgress += 1
        }
    }

    func refreshIfNeeded(state: inout GameState) {
        let now = Date()
        if now >= state.dailyQuestsRefreshAt {
            generateDailyQuests(state: &state)
            state.dailyQuestsRefreshAt = Calendar.current.startOfDay(for: now).addingTimeInterval(86400)
        }
        if now >= state.weeklyQuestsRefreshAt {
            generateWeeklyQuests(state: &state)
            state.weeklyQuestsRefreshAt = Calendar.current.startOfDay(for: now).addingTimeInterval(7*86400)
        }
    }

    func generateDailyQuests(state: inout GameState) {
        let pool = QuestDefinitionID.allCases.shuffled().prefix(3)
        state.dailyQuests = pool.map { def in
            let target = dailyTarget(for: def, level: state.level)
            let rewardCoins = Int64(dailyRewardCoins(for: def, level: state.level))
            let rewardGems = Int64(dailyRewardGems(for: def))
            return Quest(id: UUID(), definitionID: def, kind: .daily, progressTarget: target, rewardCoins: rewardCoins, rewardGems: rewardGems)
        }
    }

    func generateWeeklyQuests(state: inout GameState) {
        let pool = QuestDefinitionID.allCases.shuffled().prefix(2)
        state.weeklyQuests = pool.map { def in
            let target = dailyTarget(for: def, level: state.level) * 7
            let rewardCoins = Int64(dailyRewardCoins(for: def, level: state.level) * 8)
            let rewardGems = Int64(dailyRewardGems(for: def) * 8)
            return Quest(id: UUID(), definitionID: def, kind: .weekly, progressTarget: target, rewardCoins: rewardCoins, rewardGems: rewardGems)
        }
    }

    private func dailyTarget(for def: QuestDefinitionID, level: Int) -> Double {
        switch def {
        case .runDistance: return 500
        case .defeatMonsters: return 30
        case .defeatBosses: return 1
        case .earnCoins: return Double(1000 * level)
        case .levelUp: return 2
        case .useAbilities: return 10
        case .equipItems: return 3
        case .prestigeOnce: return 1
        case .collectGems: return 5
        case .surviveNoDeath: return 1
        }
    }

    private func dailyRewardCoins(for def: QuestDefinitionID, level: Int) -> Int {
        switch def {
        case .runDistance: return 200 * level
        case .defeatMonsters: return 250 * level
        case .defeatBosses: return 500 * level
        case .earnCoins: return 300 * level
        case .levelUp: return 400 * level
        case .useAbilities: return 200 * level
        case .equipItems: return 250 * level
        case .prestigeOnce: return 600 * level
        case .collectGems: return 150 * level
        case .surviveNoDeath: return 350 * level
        }
    }

    private func dailyRewardGems(for def: QuestDefinitionID) -> Int {
        switch def {
        case .defeatBosses, .levelUp, .prestigeOnce: return 2
        default: return 1
        }
    }
}
