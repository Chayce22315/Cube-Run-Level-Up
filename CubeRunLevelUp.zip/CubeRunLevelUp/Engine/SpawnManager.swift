import Foundation

class SpawnManager {
    // Spawn logic is handled inline in GameEngine for simplicity
    // This class reserved for future expansion (spawn pools, events, etc.)
}
