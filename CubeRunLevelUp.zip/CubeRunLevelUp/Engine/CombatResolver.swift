import Foundation

struct CombatResult {
    let damage: Double
    let isCrit: Bool
    let isDodged: Bool
}

class CombatResolver {
    func resolveAttack(
        attackerAttack: Double,
        defenderDefense: Double,
        critRate: Double,
        critDamage: Double,
        defenderDodge: Double,
        incomingMultiplier: Double
    ) -> CombatResult {
        // Dodge check
        if Double.random(in: 0..<1) < defenderDodge {
            return CombatResult(damage: 0, isCrit: false, isDodged: true)
        }

        // Base damage
        var damage = max(1, attackerAttack - defenderDefense)

        // Crit check
        var isCrit = false
        if Double.random(in: 0..<1) < critRate {
            damage *= critDamage
            isCrit = true
        }

        damage *= incomingMultiplier

        return CombatResult(damage: damage, isCrit: isCrit, isDodged: false)
    }
}
