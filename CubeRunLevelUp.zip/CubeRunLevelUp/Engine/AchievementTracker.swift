import Foundation

class AchievementTracker {
    func evaluate(state: inout GameState, engine: GameEngine) {
        for ach in AchievementID.allCases where !state.unlockedAchievements.contains(ach) {
            if ach == .completionist {
                if state.unlockedAchievements.count >= 48 {
                    unlock(ach, state: &state)
                }
                continue
            }

            let progress = currentProgress(for: ach, state: state, engine: engine)
            state.achievementProgress[ach] = progress

            if progress >= ach.threshold {
                unlock(ach, state: &state)
            }
        }
    }

    func notifyLevelUp(level: Int, state: inout GameState) {
        evaluate(state: &state, engine: GameEngine(state: state))
    }

    func notifyBossDefeated(boss: Boss, state: inout GameState) {
        evaluate(state: &state, engine: GameEngine(state: state))
    }

    func recordItemCollected(state: inout GameState) {
        evaluate(state: &state, engine: GameEngine(state: state))
    }

    private func currentProgress(for ach: AchievementID, state: GameState, engine: GameEngine) -> Double {
        switch ach {
        case .distance1, .distance2, .distance3, .distance4, .distance5:
            return state.totalDistanceAllTime
        case .combat1, .combat2, .combat3, .combat4, .combat5:
            // Monster kills lifetime not directly tracked; approximate via achievements progress
            return state.achievementProgress[ach] ?? 0
        case .leveling1, .leveling2, .leveling3, .leveling4, .leveling5:
            return Double(state.level)
        case .bosses1, .bosses2, .bosses3, .bosses4:
            return Double(state.bossesDefeated)
        case .bosses5:
            return state.achievementProgress[ach] ?? 0
        case .prestige1, .prestige2, .prestige3, .prestige4, .prestige5:
            return Double(state.prestigeCount)
        case .collection1:
            return Double(state.equippedItems.count)
        case .collection2, .collection3:
            return state.achievementProgress[ach] ?? Double(state.inventory.count + state.equippedItems.count)
        case .collection4:
            return state.inventory.contains(where: { $0.rarity == .legendary }) || state.equippedItems.values.contains(where: { $0.rarity == .legendary }) ? 1 : 0
        case .collection5:
            let allEpicPlus = state.equippedItems.values.allSatisfy { $0.rarity == .epic || $0.rarity == .legendary }
            return allEpicPlus && state.equippedItems.count == 5 ? 1 : 0
        case .wealth1, .wealth2, .wealth3, .wealth4, .wealth5:
            return Double(state.totalCoinsEarned)
        case .survival1, .survival2, .survival3, .survival4, .survival5:
            return state.achievementProgress[ach] ?? 0
        case .cosmetics1:
            return state.equippedCosmetics.skin != .defaultCube || state.equippedCosmetics.trail != .noTrail || state.equippedCosmetics.aura != .noAura ? 1 : 0
        case .cosmetics2, .cosmetics3:
            return Double(state.unlockedCosmetics.count)
        case .cosmetics4:
            return Double(state.unlockedCosmetics.count) >= Double(CosmeticID.allCases.count) ? 1 : 0
        case .dedication1, .dedication2, .dedication3, .dedication4:
            return state.achievementProgress[ach] ?? 0
        case .completionist:
            return Double(state.unlockedAchievements.count)
        }
    }

    private func unlock(_ ach: AchievementID, state: inout GameState) {
        state.unlockedAchievements.insert(ach)
        state.gems += ach.rewardGems
        HapticsService.shared.notify(.success)
    }
}
