import Foundation

struct OfflineSummary {
    let duration: TimeInterval
    let coinsEarned: Int64
    let xpEarned: Double
    let monstersDefeated: Int
    let levelsGained: Int
}

class OfflineProgressCalculator {
    func simulateOffline(from lastActive: Date, to now: Date, engine: GameEngine) -> OfflineSummary {
        let elapsed = now.timeIntervalSince(lastActive)
        guard elapsed > 60 else { return OfflineSummary(duration: 0, coinsEarned: 0, xpEarned: 0, monstersDefeated: 0, levelsGained: 0) }

        let elapsedSeconds = min(elapsed, 24 * 3600)
        let efficiency = engine.state.permanentBonuses.offlineEfficiency
        let simulatedSeconds = Int(Double(elapsedSeconds) * efficiency)

        var coinsEarned: Int64 = 0
        var xpEarned: Double = 0
        var monstersDefeated = 0
        var levelsGained = 0
        var simulatedDate = lastActive

        for _ in 0..<simulatedSeconds {
            simulatedDate.addTimeInterval(1)
            let beforeCoins = engine.state.coins
            let beforeXP = engine.state.currentXP
            let beforeLevel = engine.state.level

            if engine.state.distance >= engine.state.nextBossDistanceThreshold {
                continue
            }

            engine.tick(now: simulatedDate)

            coinsEarned += engine.state.coins - beforeCoins
            xpEarned += engine.state.currentXP - beforeXP
            if engine.state.level > beforeLevel { levelsGained += 1 }
            if engine.state.activeMonster == nil && beforeXP != engine.state.currentXP {
                monstersDefeated += 1
            }
        }

        return OfflineSummary(
            duration: elapsed,
            coinsEarned: coinsEarned,
            xpEarned: xpEarned,
            monstersDefeated: monstersDefeated,
            levelsGained: levelsGained
        )
    }
}
