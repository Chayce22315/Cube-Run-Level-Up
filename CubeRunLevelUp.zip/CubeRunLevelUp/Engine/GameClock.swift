import Foundation
import Combine

class GameClock {
    private var timer: AnyCancellable?
    let tickPublisher = PassthroughSubject<Date, Never>()
    private var isRunning = false

    func start() {
        guard !isRunning else { return }
        isRunning = true
        timer = Timer.publish(every: 1, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                self?.tickPublisher.send(Date())
            }
    }

    func stop() {
        timer?.cancel()
        timer = nil
        isRunning = false
    }
}
