import Foundation
import Combine

class GameEngine: ObservableObject {
    @Published var state: GameState

    private let clock = GameClock()
    private var cancellables = Set<AnyCancellable>()

    let combatResolver = CombatResolver()
    let spawnManager = SpawnManager()
    let progressionManager = ProgressionManager()
    let equipmentGenerator = EquipmentGenerator()
    let prestigeManager = PrestigeManager()
    let questTracker = QuestTracker()
    let achievementTracker = AchievementTracker()
    let cosmeticManager = CosmeticManager()

    var onAbilityUnlocked: ((AbilityID) -> Void)?
    var onLevelUp: ((Int) -> Void)?
    var onBossDefeated: ((Boss) -> Void)?
    var onPlayerDeath: (() -> Void)?
    var onPlayerRevive: (() -> Void)?

    init(state: GameState? = nil) {
        self.state = state ?? GameState.new()
        bindClock()
    }

    private func bindClock() {
        clock.tickPublisher
            .sink { [weak self] now in
                self?.tick(now: now)
            }
            .store(in: &cancellables)
    }

    func start() { clock.start() }
    func stop() { clock.stop() }

    func tick(now: Date) {
        guard !state.isDead else { handleDeathState(now: now); return }

        advanceDistance()
        autoBattleStep(now: now)
        regenerateHP()
        checkBossSpawn()
        if state.settings.gameplay.autoAbilities { autoCastReadyAbilities(now: now) }
        checkLevelUp()
        questTracker.recordTick(state: &state)
        achievementTracker.evaluate(state: &state, engine: self)
        state.lastActiveAt = now
    }

    func advanceDistance() {
        guard state.activeBoss == nil else { return }
        let agility = effectiveStat(.agility)
        let runSpeed = 4.0 * (1 + Double(agility) * 0.01)
        let delta = runSpeed
        state.distance += delta
        state.totalDistanceAllTime += delta
        questTracker.recordDistance(delta, state: &state)
    }

    func autoBattleStep(now: Date) {
        if state.activeMonster == nil && state.activeBoss == nil {
            state.activeMonster = Monster.spawn(atDistance: state.distance)
        }

        if let boss = state.activeBoss {
            resolveBossCombat(boss: boss, now: now)
        } else if let monster = state.activeMonster {
            resolveMonsterCombat(monster: monster, now: now)
        }
    }

    func resolveMonsterCombat(monster: Monster, now: Date) {
        var monster = monster
        let playerAttack = calculatePlayerAttack()
        let playerCrit = calculateCritChance()
        let playerCritDmg = calculateCritDamage()
        let playerDodge = calculateDodgeChance()
        let playerDefense = calculateDefense()

        // Player attacks
        let dmgToMonster = combatResolver.resolveAttack(
            attackerAttack: playerAttack,
            defenderDefense: 0,
            critRate: playerCrit,
            critDamage: playerCritDmg,
            defenderDodge: 0,
            incomingMultiplier: 1.0
        )
        monster.currentHP -= dmgToMonster.damage

        if dmgToMonster.isCrit {
            HapticsService.shared.impact(.medium)
        }

        // Vampiric heal
        if let vampUntil = state.vampiricTouchActiveUntil, now < vampUntil, dmgToMonster.damage > 0 {
            let heal = dmgToMonster.damage * 0.2
            state.currentHP = min(state.maxHP, state.currentHP + heal)
        }

        if monster.currentHP <= 0 {
            defeatMonster(monster)
            return
        }

        // Monster attacks back
        let dmgToPlayer = combatResolver.resolveAttack(
            attackerAttack: monster.damage,
            defenderDefense: playerDefense,
            critRate: 0,
            critDamage: 1.5,
            defenderDodge: playerDodge,
            incomingMultiplier: effectiveIncomingDamageMultiplier(now: now)
        )
        if dmgToPlayer.isDodged {
            // miss
        } else {
            state.currentHP -= dmgToPlayer.damage
            if dmgToPlayer.damage > 0 {
                HapticsService.shared.impact(.light)
            }
        }

        if state.currentHP <= 0 {
            triggerDeath(now: now)
        }

        state.activeMonster = monster
    }

    func resolveBossCombat(boss: Boss, now: Date) {
        var boss = boss
        boss.updatePhase()

        let playerAttack = calculatePlayerAttack()
        let playerCrit = calculateCritChance()
        let playerCritDmg = calculateCritDamage()
        let playerDodge = calculateDodgeChance()
        let playerDefense = calculateDefense()

        let attackSpeedMult = effectiveAttackSpeedMultiplier(now: now)
        let attacksThisTick = max(1, Int(attackSpeedMult))

        for _ in 0..<attacksThisTick {
            let dmgToBoss = combatResolver.resolveAttack(
                attackerAttack: playerAttack,
                defenderDefense: 0,
                critRate: playerCrit,
                critDamage: playerCritDmg,
                defenderDodge: 0,
                incomingMultiplier: 1.0
            )
            boss.currentHP -= dmgToBoss.damage

            if dmgToBoss.isCrit { HapticsService.shared.impact(.medium) }

            if let vampUntil = state.vampiricTouchActiveUntil, now < vampUntil, dmgToBoss.damage > 0 {
                let heal = dmgToBoss.damage * 0.2
                state.currentHP = min(state.maxHP, state.currentHP + heal)
            }
        }

        if boss.currentHP <= 0 {
            defeatBoss(boss)
            return
        }

        // Boss abilities
        for i in boss.abilities.indices {
            var ability = boss.abilities[i]
            let cooldownEnd = ability.lastUsedAt?.addingTimeInterval(ability.cooldownSeconds) ?? Date.distantPast
            if now >= cooldownEnd {
                // Telegraph
                if ability.nextTelegraphEndsAt == nil {
                    ability.nextTelegraphEndsAt = now.addingTimeInterval(ability.telegraphSeconds)
                    boss.abilities[i] = ability
                    continue
                }
                if let telegraphEnd = ability.nextTelegraphEndsAt, now >= telegraphEnd {
                    // Fire ability
                    applyBossAbility(ability, boss: boss, now: now)
                    ability.lastUsedAt = now
                    ability.nextTelegraphEndsAt = nil
                    boss.abilities[i] = ability
                }
            }
        }

        // Boss basic attack
        let bossDmgMult = boss.phaseDamageMultiplier * (boss.isEnraged ? 2.0 : 1.0)
        let dmgToPlayer = combatResolver.resolveAttack(
            attackerAttack: boss.damage * bossDmgMult,
            defenderDefense: playerDefense,
            critRate: 0,
            critDamage: 1.5,
            defenderDodge: playerDodge,
            incomingMultiplier: effectiveIncomingDamageMultiplier(now: now)
        )
        if !dmgToPlayer.isDodged && dmgToPlayer.damage > 0 {
            state.currentHP -= dmgToPlayer.damage
            HapticsService.shared.impact(.heavy)
        }

        if state.currentHP <= 0 {
            triggerDeath(now: now)
        }

        // Enrage check
        let elapsed = now.timeIntervalSince(boss.spawnedAt)
        if !boss.isEnraged && elapsed >= Double(boss.enrageTimerSeconds) {
            boss.isEnraged = true
        }

        state.activeBoss = boss
    }

    func applyBossAbility(_ ability: BossAbility, boss: Boss, now: Date) {
        let playerDefense = calculateDefense()
        let playerDodge = calculateDodgeChance()
        let mult = boss.phaseDamageMultiplier * (boss.isEnraged ? 2.0 : 1.0)

        switch ability.effect {
        case .directDamage(let multiplier):
            let dmg = combatResolver.resolveAttack(
                attackerAttack: boss.damage * multiplier * mult,
                defenderDefense: playerDefense,
                critRate: 0, critDamage: 1.5,
                defenderDodge: playerDodge,
                incomingMultiplier: effectiveIncomingDamageMultiplier(now: now)
            )
            if !dmg.isDodged && dmg.damage > 0 {
                state.currentHP -= dmg.damage
                HapticsService.shared.impact(.heavy)
            }
        case .damageOverTime(let multiplier, let ticks):
            // DOT applied over future ticks; simplified: apply one tick now, store remainder
            let tickDmg = combatResolver.resolveAttack(
                attackerAttack: boss.damage * multiplier * mult,
                defenderDefense: playerDefense,
                critRate: 0, critDamage: 1.5,
                defenderDodge: playerDodge,
                incomingMultiplier: effectiveIncomingDamageMultiplier(now: now)
            )
            if !tickDmg.isDodged && tickDmg.damage > 0 {
                state.currentHP -= tickDmg.damage
            }
        }
    }

    func defeatMonster(_ monster: Monster) {
        let coinBonus = calculateCoinBonus()
        let xpBonus = calculateXPBonus()
        let coinsEarned = Int64(monster.maxHP * 0.5 * coinBonus)
        let xpEarned = monster.maxHP * 0.3 * xpBonus

        addCoins(coinsEarned)
        state.currentXP += xpEarned
        questTracker.recordMonsterKill(state: &state)

        // Drop
        if Double.random(in: 0..<1) < 0.08 {
            let item = equipmentGenerator.generate(playerLevel: state.level)
            considerAutoEquip(newItem: item)
        }

        state.activeMonster = nil
    }

    func defeatBoss(_ boss: Boss) {
        let coinsEarned = Int64(boss.maxHP * 2)
        let xpEarned = boss.maxHP * 1.5
        let gemsEarned = Int64(1 + (boss.number / 5))

        addCoins(coinsEarned)
        state.currentXP += xpEarned
        state.gems += gemsEarned

        state.bossesDefeated += 1
        state.nextBossDistanceThreshold += 1000

        // Guaranteed drop
        let item = equipmentGenerator.generate(playerLevel: state.level, forceRarity: nil)
        considerAutoEquip(newItem: item)

        questTracker.recordBossKill(state: &state)
        achievementTracker.notifyBossDefeated(boss: boss, state: &state)

        state.activeBoss = nil
        onBossDefeated?(boss)
    }

    func triggerDeath(now: Date) {
        state.isDead = true
        state.deathCount += 1
        state.reviveCooldownEndsAt = now.addingTimeInterval(5)
        questTracker.recordDeath(state: &state)
        HapticsService.shared.notify(.error)
        onPlayerDeath?()
    }

    func handleDeathState(now: Date) {
        if let reviveTime = state.reviveCooldownEndsAt, now >= reviveTime {
            revivePlayer()
        }
    }

    func revivePlayer() {
        state.isDead = false
        state.currentHP = state.maxHP * 0.5
        state.reviveCooldownEndsAt = nil
        HapticsService.shared.notify(.success)
        onPlayerRevive?()
    }

    func regenerateHP() {
        let vit = effectiveStat(.vitality)
        let regen = 1 + Double(vit) * 0.5
        state.currentHP = min(state.maxHP, state.currentHP + regen)
    }

    func checkBossSpawn() {
        if state.distance >= state.nextBossDistanceThreshold && state.activeBoss == nil {
            state.activeMonster = nil
            let bossNumber = state.bossesDefeated + 1
            state.activeBoss = Boss.spawn(number: bossNumber)
        }
    }

    func checkLevelUp() {
        while state.currentXP >= xpRequired(for: state.level) {
            state.currentXP -= xpRequired(for: state.level)
            state.level += 1
            state.unspentStatPoints += 3
            recomputeMaxHP()
            state.currentHP = state.maxHP
            checkAbilityUnlock(atLevel: state.level)
            achievementTracker.notifyLevelUp(level: state.level, state: &state)
            questTracker.recordLevelUp(state: &state)
            HapticsService.shared.notify(.success)
            onLevelUp?(state.level)
        }
    }

    func checkAbilityUnlock(atLevel level: Int) {
        for ability in AbilityID.allCases {
            if level >= ability.unlockLevel && !state.unlockedAbilities.contains(ability) {
                state.unlockedAbilities.append(ability)
                onAbilityUnlocked?(ability)
            }
        }
    }

    func xpRequired(for level: Int) -> Double {
        100 * pow(1.15, Double(level))
    }

    func autoCastReadyAbilities(now: Date) {
        let hpPct = state.currentHP / state.maxHP
        let threshold = state.settings.gameplay.autoHealThreshold
        let needsHeal = hpPct < threshold

        let ready = state.unlockedAbilities.filter { id in
            if let cd = state.abilityCooldowns[id] { return now >= cd }
            return true
        }

        // Priority 1: Heal
        if needsHeal {
            for id in ready where id.isHealCapable {
                castAbility(id, now: now)
                return
            }
        }

        // Priority 2: Cube Rage finisher
        if let boss = state.activeBoss, boss.currentHP / boss.maxHP < 0.3, ready.contains(.cubeRage) {
            castAbility(.cubeRage, now: now)
            return
        }

        // Priority 3: Power Strike on boss
        if state.activeBoss != nil, ready.contains(.powerStrike) {
            castAbility(.powerStrike, now: now)
            return
        }

        // Priority 4: Utility
        for id in [.adrenaline, .timeWarp] as [AbilityID] {
            if ready.contains(id) { castAbility(id, now: now); return }
        }

        // Priority 5: Defensive if telegraph imminent
        if let boss = state.activeBoss {
            for ability in boss.abilities {
                if let telegraphEnd = ability.nextTelegraphEndsAt,
                   telegraphEnd.timeIntervalSince(now) <= 2 {
                    if ready.contains(.fortify) { castAbility(.fortify, now: now); return }
                    if ready.contains(.shieldWall) { castAbility(.shieldWall, now: now); return }
                }
            }
        }

        // Priority 6: Whirlwind filler
        if ready.contains(.whirlwind) {
            castAbility(.whirlwind, now: now)
            return
        }
    }

    func castAbility(_ id: AbilityID, now: Date) {
        state.abilityCooldowns[id] = now.addingTimeInterval(id.cooldownSeconds)
        questTracker.recordAbilityUse(state: &state)

        switch id {
        case .powerStrike:
            state.outgoingDamageMultiplier = 3.0
            state.outgoingDamageMultiplierExpiresAt = now.addingTimeInterval(1)
        case .shieldWall:
            state.incomingDamageMultiplier = 0.5
            state.incomingDamageMultiplierExpiresAt = now.addingTimeInterval(5)
        case .adrenaline:
            state.attackSpeedMultiplier = 1.75
            state.attackSpeedMultiplierExpiresAt = now.addingTimeInterval(8)
        case .vampiricTouch:
            state.vampiricTouchActiveUntil = now.addingTimeInterval(6)
        case .whirlwind:
            state.outgoingDamageMultiplier = 1.5
            state.outgoingDamageMultiplierExpiresAt = now.addingTimeInterval(1)
        case .fortify:
            state.incomingDamageMultiplier = 0.25
            state.incomingDamageMultiplierExpiresAt = now.addingTimeInterval(6)
            // Attack -25% handled in calculatePlayerAttack
        case .timeWarp:
            // Accelerate other cooldowns
            for (otherID, cdEnd) in state.abilityCooldowns where otherID != .timeWarp {
                let remaining = cdEnd.timeIntervalSince(now)
                if remaining > 0 {
                    state.abilityCooldowns[otherID] = now.addingTimeInterval(remaining / 3)
                }
            }
        case .cubeRage:
            state.outgoingDamageMultiplier = 2.0
            state.outgoingDamageMultiplierExpiresAt = now.addingTimeInterval(8)
            state.attackSpeedMultiplier = 1.5
            state.attackSpeedMultiplierExpiresAt = now.addingTimeInterval(8)
            state.cubeRageActiveUntil = now.addingTimeInterval(8)
        }
    }

    func effectiveIncomingDamageMultiplier(now: Date) -> Double {
        var mult = 1.0
        if let expires = state.incomingDamageMultiplierExpiresAt, now < expires {
            mult *= state.incomingDamageMultiplier
        }
        return mult
    }

    func effectiveAttackSpeedMultiplier(now: Date) -> Double {
        var mult = 1.0
        if let expires = state.attackSpeedMultiplierExpiresAt, now < expires {
            mult *= state.attackSpeedMultiplier
        }
        return mult
    }

    func calculatePlayerAttack() -> Double {
        let str = effectiveStat(.strength)
        var atk = 10 + Double(str) * 2
        atk *= state.permanentBonuses.damageMultiplier
        if let expires = state.outgoingDamageMultiplierExpiresAt, Date() < expires {
            atk *= state.outgoingDamageMultiplier
        }
        // Fortify penalty
        if let expires = state.incomingDamageMultiplierExpiresAt, Date() < expires,
           state.incomingDamageMultiplier == 0.25 {
            atk *= 0.75
        }
        return atk
    }

    func calculateDefense() -> Double {
        let def = effectiveStat(.defense)
        return 5 + Double(def) * 2
    }

    func calculateMaxHP() -> Double {
        let vit = effectiveStat(.vitality)
        return 100 + Double(vit) * 20
    }

    func recomputeMaxHP() {
        state.maxHP = calculateMaxHP()
    }

    func calculateCritChance() -> Double {
        let agi = effectiveStat(.agility)
        return min(0.75, 0.01 + Double(agi) * 0.005)
    }

    func calculateCritDamage() -> Double {
        let str = effectiveStat(.strength)
        return 1.5 + Double(str) * 0.01
    }

    func calculateDodgeChance() -> Double {
        let agi = effectiveStat(.agility)
        return min(0.60, Double(agi) * 0.005)
    }

    func calculateCoinBonus() -> Double {
        let int = effectiveStat(.intelligence)
        var bonus = 1 + Double(int) * 0.02
        bonus *= state.permanentBonuses.coinMultiplier
        return bonus
    }

    func calculateXPBonus() -> Double {
        let int = effectiveStat(.intelligence)
        var bonus = 1 + Double(int) * 0.03
        bonus *= state.permanentBonuses.xpMultiplier
        return bonus
    }

    func effectiveStat(_ stat: StatType) -> Int {
        var total = state.stats.value(for: stat)
        for item in state.equippedItems.values {
            if item.baseStatType == stat { total += item.baseStatValue }
            if item.secondaryStatType == stat, let sec = item.secondaryStatValue { total += sec }
        }
        // Cosmetic set bonus
        let setBonus = cosmeticManager.activeSetBonus(state: state)
        if setBonus.stat == stat { total += setBonus.value }
        return total
    }

    func addCoins(_ amount: Int64) {
        let capped = min(amount, Int64(Int32.max) - state.coins)
        state.coins += capped
        state.totalCoinsEarned += amount
        questTracker.recordCoins(amount, state: &state)
    }

    func considerAutoEquip(newItem: Equipment) {
        guard state.settings.gameplay.autoEquip else {
            addToInventory(newItem)
            return
        }
        if let equipped = state.equippedItems[newItem.slot] {
            if newItem.powerScore > equipped.powerScore {
                addToInventory(equipped)
                state.equippedItems[newItem.slot] = newItem
                recomputeMaxHP()
            } else {
                addToInventory(newItem)
            }
        } else {
            state.equippedItems[newItem.slot] = newItem
            recomputeMaxHP()
        }
    }

    func addToInventory(_ item: Equipment) {
        state.inventory.append(item)
        achievementTracker.recordItemCollected(state: &state)
        if state.inventory.count > 200 {
            autoSellLowestItem()
        }
    }

    func autoSellLowestItem() {
        guard let index = state.inventory.enumerated()
            .filter({ $0.element.rarity == .common || $0.element.rarity == .uncommon })
            .min(by: { $0.element.powerScore < $1.element.powerScore })?.offset else { return }
        let item = state.inventory.remove(at: index)
        let sellValue = Int64(item.itemLevel * 5)
        addCoins(sellValue)
    }

    func manualAttack() {
        // Visual-only tap; damage is tick-based. This triggers animation.
        HapticsService.shared.impact(.light)
    }

    func prestige() -> Int64 {
        let souls = prestigeManager.calculateSouls(state: state)
        prestigeManager.applyPrestige(state: &state)
        return souls
    }
}
