import SwiftUI

struct PrestigeView: View {
    @ObservedObject var engine: GameEngine
    @State private var showConfirm = false

    var isEligible: Bool { engine.state.level >= 25 || engine.state.distance >= 10000 }
    var soulsPreview: Int64 { engine.prestigeManager.calculateSouls(state: engine.state) }

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 20) {
                    if !isEligible {
                        VStack(spacing: 8) {
                            Text("Prestige Locked")
                                .font(.title2.bold())
                            ProgressBarView(value: Double(engine.state.level), max: 25)
                                .frame(height: 12)
                            Text("Level: \(engine.state.level)/25")
                            ProgressBarView(value: engine.state.distance, max: 10000)
                                .frame(height: 12)
                            Text("Distance: \(Int(engine.state.distance))/10000m")
                        }
                        .padding()
                        .background(Color.gray.opacity(0.1))
                        .cornerRadius(12)
                    } else {
                        VStack(spacing: 8) {
                            Text("Prestige Ready!")
                                .font(.title2.bold())
                                .foregroundColor(.orange)
                            Text("Souls to gain: \(soulsPreview)")
                                .font(.headline)
                            Button("Prestige Now") {
                                showConfirm = true
                            }
                            .padding()
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                        }
                        .padding()
                        .background(Color.orange.opacity(0.1))
                        .cornerRadius(12)
                    }

                    Divider()

                    Text("Permanent Bonuses")
                        .font(.headline)

                    ForEach(BonusType.allCases, id: \ .self) { bonus in
                        BonusRow(engine: engine, bonus: bonus)
                    }
                }
                .padding()
            }
            .navigationTitle("Prestige")
            .confirmationDialog("Confirm Prestige?", isPresented: $showConfirm, titleVisibility: .visible) {
                Button("Prestige (Gain \(soulsPreview) Souls)", role: .destructive) {
                    _ = engine.prestige()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("This will reset your level, distance, stats, gear, and abilities. Souls and gems are kept.")
            }
        }
    }
}

struct BonusRow: View {
    @ObservedObject var engine: GameEngine
    let bonus: BonusType

    var currentLevel: Int {
        switch bonus {
        case .coinMultiplier: return engine.state.permanentBonuses.coinMultiplierLevel
        case .xpMultiplier: return engine.state.permanentBonuses.xpMultiplierLevel
        case .startingDistance: return engine.state.permanentBonuses.startingDistanceLevel
        case .damageMultiplier: return engine.state.permanentBonuses.damageMultiplierLevel
        case .offlineEfficiency: return engine.state.permanentBonuses.offlineEfficiencyLevel
        }
    }

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(bonus.rawValue)
                    .font(.subheadline.bold())
                Text(bonus.description)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Text("Lv \(currentLevel)/\(engine.state.permanentBonuses.maxLevel(for: bonus))")
            let cost = engine.state.permanentBonuses.costForNextLevel(of: bonus)
            Button("Buy (\(cost))") {
                if engine.state.souls >= cost {
                    engine.state.souls -= cost
                    _ = engine.state.permanentBonuses.purchase(bonus)
                }
            }
            .disabled(engine.state.souls < cost || currentLevel >= engine.state.permanentBonuses.maxLevel(for: bonus))
            .font(.caption)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(engine.state.souls >= cost ? Color.orange : Color.gray)
            .foregroundColor(.white)
            .cornerRadius(4)
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }
}
