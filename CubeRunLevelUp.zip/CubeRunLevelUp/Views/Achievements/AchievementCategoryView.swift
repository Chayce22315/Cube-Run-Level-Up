import SwiftUI

struct AchievementCategoryView: View {
    @ObservedObject var engine: GameEngine
    let category: AchievementCategory
    @State private var isExpanded = false

    var achievements: [AchievementID] {
        AchievementID.allCases.filter { $0.category == category }
    }

    var body: some View {
        DisclosureGroup(
            isExpanded: $isExpanded,
            content: {
                ForEach(achievements, id: \ .self) { ach in
                    AchievementRow(engine: engine, ach: ach)
                }
            },
            label: {
                Text(category.rawValue.capitalized)
                    .font(.subheadline.bold())
            }
        )
    }
}

struct AchievementRow: View {
    @ObservedObject var engine: GameEngine
    let ach: AchievementID

    var isUnlocked: Bool { engine.state.unlockedAchievements.contains(ach) }
    var progress: Double { engine.state.achievementProgress[ach] ?? 0 }

    var body: some View {
        HStack {
            Image(systemName: isUnlocked ? "checkmark.circle.fill" : "lock.circle")
                .foregroundColor(isUnlocked ? .green : .gray)
            VStack(alignment: .leading, spacing: 2) {
                Text(ach.title)
                    .font(.caption.bold())
                Text(ach.description)
                    .font(.caption2)
                    .foregroundColor(.secondary)
                if !isUnlocked, ach.threshold > 1 {
                    ProgressBarView(value: progress, maxValue: ach.threshold)
                        .frame(height: 4)
                }
            }
            Spacer()
            Text("💎 \(ach.rewardGems)")
                .font(.caption)
        }
        .padding(.vertical, 2)
    }
}
