import SwiftUI

struct AchievementsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        NavigationView {
            List {
                Text("\(engine.state.unlockedAchievements.count) / 49 Unlocked")
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .center)

                ForEach(AchievementCategory.allCases, id: \ .self) { category in
                    AchievementCategoryView(engine: engine, category: category)
                }
            }
            .navigationTitle("Achievements")
        }
    }
}
