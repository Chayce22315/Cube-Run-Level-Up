import SwiftUI

struct HUDView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                CurrencyPillView(icon: "circle.fill", value: engine.state.coins, color: .yellow)
                Spacer()
                VStack(spacing: 2) {
                    Text("Lv \(engine.state.level)")
                        .font(.caption.bold())
                    ProgressBarView(value: engine.state.currentXP, max: engine.xpRequired(for: engine.state.level))
                        .frame(width: 120, height: 6)
                }
                Spacer()
                CurrencyPillView(icon: "diamond.fill", value: engine.state.gems, color: .cyan)
            }
            .padding(.horizontal)
            .padding(.top, 8)

            HStack {
                Spacer()
                Text("\(engine.state.distance.abbreviated())m")
                    .font(.caption2)
                    .foregroundColor(.white)
                    .shadow(radius: 2)
                Spacer()
            }
            .padding(.top, 4)

            Spacer()

            // HP Bar following cube
            GeometryReader { geo in
                VStack {
                    Spacer()
                    HStack {
                        Spacer().frame(width: 60)
                        VStack(spacing: 2) {
                            ProgressBarView(value: engine.state.currentHP, max: engine.state.maxHP, foregroundColor: .red)
                                .frame(width: 80, height: 8)
                            if engine.state.isDead {
                                Text("REVIVING...")
                                    .font(.caption2.bold())
                                    .foregroundColor(.red)
                            }
                        }
                        Spacer()
                    }
                    .padding(.bottom, 120)
                }
            }
        }
    }
}
