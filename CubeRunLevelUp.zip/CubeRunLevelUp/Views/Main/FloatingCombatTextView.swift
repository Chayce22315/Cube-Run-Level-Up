import SwiftUI

struct FloatingCombatTextView: View {
    let text: String
    let color: Color
    @State private var offset: CGFloat = 0
    @State private var opacity: Double = 1

    var body: some View {
        Text(text)
            .font(.caption.bold())
            .foregroundColor(color)
            .shadow(radius: 1)
            .offset(y: offset)
            .opacity(opacity)
            .onAppear {
                withAnimation(.easeOut(duration: 1)) {
                    offset = -40
                    opacity = 0
                }
            }
    }
}
