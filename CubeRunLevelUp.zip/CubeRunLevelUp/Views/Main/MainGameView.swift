import SwiftUI
import SpriteKit

struct MainGameView: View {
    @ObservedObject var engine: GameEngine
    @StateObject private var bridge = SceneBridge()
    @State private var showAbilityDrawer = false

    var body: some View {
        ZStack {
            SpriteView(scene: makeScene(), options: [.allowsTransparency])
                .ignoresSafeArea()

            HUDView(engine: engine)

            VStack {
                Spacer()
                AbilityBarView(engine: engine, isExpanded: $showAbilityDrawer)
                    .padding(.bottom, 8)
            }
        }
        .onAppear {
            bridge.sync(with: engine)
        }
    }

    func makeScene() -> SKScene {
        let scene = RunnerScene(size: CGSize(width: 390, height: 844))
        scene.engine = engine
        scene.bridge = bridge
        return scene
    }
}
