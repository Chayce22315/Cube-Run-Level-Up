import SwiftUI

struct GraphicsSettingsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        Form {
            Picker("Preset", selection: $engine.state.settings.graphics) {
                ForEach(GraphicsPreset.allCases, id: \ .self) { preset in
                    Text(preset.rawValue).tag(preset)
                }
            }
            Toggle("Show FPS", isOn: .constant(false))
        }
        .navigationTitle("Graphics")
    }
}
