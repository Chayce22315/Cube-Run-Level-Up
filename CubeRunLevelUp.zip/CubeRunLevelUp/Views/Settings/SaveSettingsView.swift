import SwiftUI

struct SaveSettingsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        Form {
            Toggle("Auto-Save", isOn: $engine.state.settings.save.autoSaveEnabled)
            VStack(alignment: .leading) {
                Text("Frequency: \(Int(engine.state.settings.save.autoSaveFrequencySeconds))s")
                Slider(value: $engine.state.settings.save.autoSaveFrequencySeconds, in: 5...60, step: 5)
            }
            Toggle("iCloud Sync", isOn: $engine.state.settings.save.iCloudSyncEnabled)
            Button("Manual Save Now") {
                SaveManager.shared.save(state: engine.state)
            }
        }
        .navigationTitle("Save")
    }
}
