import SwiftUI

struct SettingsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        NavigationView {
            List {
                Section {
                    NavigationLink("Gameplay") { GameplaySettingsView(engine: engine) }
                    NavigationLink("Graphics") { GraphicsSettingsView(engine: engine) }
                    NavigationLink("Audio") { AudioSettingsView(engine: engine) }
                    NavigationLink("Save") { SaveSettingsView(engine: engine) }
                    NavigationLink("Notifications") { NotificationSettingsView(engine: engine) }
                    NavigationLink("Analytics") { AnalyticsSettingsView(engine: engine) }
                }
                Section {
                    Text("Version 1.0.0")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            .navigationTitle("Settings")
        }
    }
}
