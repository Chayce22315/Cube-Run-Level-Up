import SwiftUI

struct GameplaySettingsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        Form {
            Toggle("Manual Tap Attacks", isOn: $engine.state.settings.gameplay.manualTapAttacks)
            Toggle("Auto-Abilities", isOn: $engine.state.settings.gameplay.autoAbilities)
            Toggle("Auto-Collect", isOn: $engine.state.settings.gameplay.autoCollect)
            Toggle("Auto-Level-Up", isOn: $engine.state.settings.gameplay.autoLevelUp)
            Toggle("Auto-Equip", isOn: $engine.state.settings.gameplay.autoEquip)
            VStack(alignment: .leading) {
                Text("Auto-Heal Threshold: \(Int(engine.state.settings.gameplay.autoHealThreshold * 100))%")
                Slider(value: $engine.state.settings.gameplay.autoHealThreshold, in: 0.1...0.9)
            }
        }
        .navigationTitle("Gameplay")
    }
}
