import SwiftUI

struct AnalyticsSettingsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        Form {
            Toggle("Enable Local Analytics", isOn: $engine.state.settings.analytics.enabled)
            Button("Export My Data") {
                // Present share sheet
            }
            Button("Clear Analytics Data", role: .destructive) {
                AnalyticsService.shared.clear()
            }
        }
        .navigationTitle("Analytics")
    }
}
