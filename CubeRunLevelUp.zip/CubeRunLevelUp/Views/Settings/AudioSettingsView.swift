import SwiftUI

struct AudioSettingsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        Form {
            VStack(alignment: .leading) {
                Text("Master Volume: \(Int(engine.state.settings.audio.masterVolume * 100))%")
                Slider(value: $engine.state.settings.audio.masterVolume)
            }
            VStack(alignment: .leading) {
                Text("Music Volume: \(Int(engine.state.settings.audio.musicVolume * 100))%")
                Slider(value: $engine.state.settings.audio.musicVolume)
            }
            VStack(alignment: .leading) {
                Text("SFX Volume: \(Int(engine.state.settings.audio.sfxVolume * 100))%")
                Slider(value: $engine.state.settings.audio.sfxVolume)
            }
            Toggle("Haptics", isOn: $engine.state.settings.audio.hapticsEnabled)
            Toggle("Background Audio", isOn: $engine.state.settings.audio.backgroundAudio)
        }
        .navigationTitle("Audio")
    }
}
