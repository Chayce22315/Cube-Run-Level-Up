import SwiftUI

struct NotificationSettingsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        Form {
            Toggle("Enable Notifications", isOn: $engine.state.settings.notifications.enabled)
            Toggle("Boss Available", isOn: $engine.state.settings.notifications.bossAvailable)
            Toggle("Offline Earnings Ready", isOn: $engine.state.settings.notifications.offlineEarningsReady)
        }
        .navigationTitle("Notifications")
        .onChange(of: engine.state.settings.notifications.enabled) { enabled in
            if enabled { NotificationService.shared.requestPermission() }
        }
    }
}
