import SwiftUI

struct RarityBorderModifier<Content: View>: View {
    let content: Content
    let rarity: EquipmentRarity

    var body: some View {
        content
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.forRarity(rarity), lineWidth: 2)
            )
    }
}
