import SwiftUI

struct ProgressBarView: View {
    let value: Double
    let maxValue: Double
    var foregroundColor: Color = .blue
    var backgroundColor: Color = .gray.opacity(0.3)

    var body: some View {
        GeometryReader { geo in
            ZStack(alignment: .leading) {
                Rectangle()
                    .fill(backgroundColor)
                Rectangle()
                    .fill(foregroundColor)
                    .frame(width: geo.size.width * CGFloat(min(1, max(0, value / maxValue))))
            }
        }
        .cornerRadius(2)
    }
}
