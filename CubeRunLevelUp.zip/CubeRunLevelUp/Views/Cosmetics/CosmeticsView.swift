import SwiftUI

struct CosmeticsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        NavigationView {
            List {
                ForEach(CosmeticSlotType.allCases, id: \ .self) { slot in
                    Section(header: Text(slot.rawValue.capitalized)) {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 12) {
                                ForEach(availableCosmetics(for: slot), id: \ .self) { cosmetic in
                                    CosmeticSlotView(engine: engine, cosmetic: cosmetic, slot: slot)
                                }
                            }
                            .padding(.horizontal)
                        }
                    }
                }
            }
            .navigationTitle("Cosmetics")
        }
    }

    func availableCosmetics(for slot: CosmeticSlotType) -> [CosmeticID] {
        CosmeticID.allCases.filter { $0.slot == slot }
    }
}
