import SwiftUI

struct CosmeticSlotView: View {
    @ObservedObject var engine: GameEngine
    let cosmetic: CosmeticID
    let slot: CosmeticSlotType

    var isUnlocked: Bool { engine.state.unlockedCosmetics.contains(cosmetic) }
    var isEquipped: Bool {
        switch slot {
        case .skin: return engine.state.equippedCosmetics.skin == cosmetic
        case .trail: return engine.state.equippedCosmetics.trail == cosmetic
        case .aura: return engine.state.equippedCosmetics.aura == cosmetic
        case .effect: return engine.state.equippedCosmetics.effect == cosmetic
        case .title: return engine.state.equippedCosmetics.title == cosmetic
        }
    }

    var body: some View {
        VStack {
            ZStack {
                RoundedRectangle(cornerRadius: 8)
                    .fill(isEquipped ? Color.blue.opacity(0.3) : Color.gray.opacity(0.2))
                    .frame(width: 70, height: 70)

                if !isUnlocked {
                    Image(systemName: "lock.fill")
                        .foregroundColor(.white)
                } else {
                    Text(cosmetic.displayName.prefix(1))
                        .font(.title)
                }

                if isEquipped {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.green)
                        .offset(x: 20, y: -20)
                }
            }
            Text(cosmetic.displayName)
                .font(.caption2)
                .lineLimit(1)
        }
        .onTapGesture {
            guard isUnlocked else { return }
            switch slot {
            case .skin: engine.state.equippedCosmetics.skin = cosmetic
            case .trail: engine.state.equippedCosmetics.trail = cosmetic
            case .aura: engine.state.equippedCosmetics.aura = cosmetic
            case .effect: engine.state.equippedCosmetics.effect = cosmetic
            case .title: engine.state.equippedCosmetics.title = cosmetic
            }
            engine.recomputeMaxHP()
        }
    }
}
