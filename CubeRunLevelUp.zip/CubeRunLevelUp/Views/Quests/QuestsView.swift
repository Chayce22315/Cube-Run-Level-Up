import SwiftUI

struct QuestsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        NavigationView {
            List {
                Section(header: QuestHeader(title: "Daily", refreshAt: engine.state.dailyQuestsRefreshAt)) {
                    ForEach(engine.state.dailyQuests) { quest in
                        QuestRowView(engine: engine, quest: quest)
                    }
                }
                Section(header: QuestHeader(title: "Weekly", refreshAt: engine.state.weeklyQuestsRefreshAt)) {
                    ForEach(engine.state.weeklyQuests) { quest in
                        QuestRowView(engine: engine, quest: quest)
                    }
                }
            }
            .navigationTitle("Quests")
        }
    }
}

struct QuestHeader: View {
    let title: String
    let refreshAt: Date

    var body: some View {
        HStack {
            Text(title)
            Spacer()
            Text("Resets: \(timeString)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }

    var timeString: String {
        let formatter = RelativeDateTimeFormatter()
        return formatter.localizedString(for: refreshAt, relativeTo: Date())
    }
}
