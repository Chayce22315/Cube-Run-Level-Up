import SwiftUI

struct QuestRowView: View {
    @ObservedObject var engine: GameEngine
    let quest: Quest

    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(quest.definitionID.displayName)
                    .font(.subheadline.bold())
                ProgressBarView(value: quest.currentProgress, max: quest.progressTarget)
                    .frame(height: 6)
                Text("\(Int(quest.currentProgress))/\(Int(quest.progressTarget))")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 2) {
                Text("🪙 \(quest.rewardCoins.abbreviated())")
                    .font(.caption)
                Text("💎 \(quest.rewardGems)")
                    .font(.caption)
                if quest.isComplete && !quest.isClaimed {
                    Button("Claim") {
                        engine.state.coins += quest.rewardCoins
                        engine.state.gems += quest.rewardGems
                        if let idx = engine.state.dailyQuests.firstIndex(where: { $0.id == quest.id }) {
                            engine.state.dailyQuests[idx].isClaimed = true
                        } else if let idx = engine.state.weeklyQuests.firstIndex(where: { $0.id == quest.id }) {
                            engine.state.weeklyQuests[idx].isClaimed = true
                        }
                    }
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(4)
                } else if quest.isClaimed {
                    Text("Claimed")
                        .font(.caption)
                        .foregroundColor(.green)
                }
            }
        }
        .padding(.vertical, 4)
    }
}
