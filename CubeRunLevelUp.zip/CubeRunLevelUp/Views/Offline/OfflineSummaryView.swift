import SwiftUI

struct OfflineSummaryView: View {
    let summary: OfflineSummary
    let onContinue: () -> Void

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 20) {
                Text("Welcome Back!")
                    .font(.largeTitle.bold())
                    .foregroundColor(.white)

                Text("Away for \(timeString)")
                    .font(.title3)
                    .foregroundColor(.gray)

                VStack(spacing: 12) {
                    SummaryRow(icon: "dollarsign.circle.fill", label: "Coins Earned", value: summary.coinsEarned.abbreviated())
                    SummaryRow(icon: "star.circle.fill", label: "XP Earned", value: "\(Int(summary.xpEarned))")
                    SummaryRow(icon: "figure.walk", label: "Monsters Defeated", value: "\(summary.monstersDefeated)")
                    if summary.levelsGained > 0 {
                        Text("You reached Level \(summary.levelsGained)!")
                            .font(.headline)
                            .foregroundColor(.yellow)
                    }
                }
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(12)

                Spacer()

                Button("Continue") {
                    onContinue()
                }
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(12)
            }
            .padding()
        }
    }

    var timeString: String {
        let hours = Int(summary.duration) / 3600
        let mins = (Int(summary.duration) % 3600) / 60
        if hours > 0 { return "\(hours)h \(mins)m" }
        return "\(mins)m"
    }
}

struct SummaryRow: View {
    let icon: String
    let label: String
    let value: String

    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.yellow)
            Text(label)
                .foregroundColor(.white)
            Spacer()
            Text(value)
                .font(.headline)
                .foregroundColor(.yellow)
        }
    }
}
