import SwiftUI

struct BossHealthBarView: View {
    let boss: Boss

    var body: some View {
        VStack(spacing: 4) {
            Text("Boss #\(boss.number)")
                .font(.headline)
                .foregroundColor(.white)
            ProgressBarView(
                value: boss.currentHP,
                max: boss.maxHP,
                foregroundColor: phaseColor
            )
            .frame(height: 20)
            .overlay(
                Text("\(Int(boss.currentHP))/\(Int(boss.maxHP))")
                    .font(.caption2)
                    .foregroundColor(.white)
            )
        }
    }

    var phaseColor: Color {
        switch boss.phase {
        case 2: return .yellow
        case 3: return .red
        default: return .green
        }
    }
}
