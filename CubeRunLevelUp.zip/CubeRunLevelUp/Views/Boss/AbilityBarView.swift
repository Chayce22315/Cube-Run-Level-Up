import SwiftUI

struct AbilityBarView: View {
    @ObservedObject var engine: GameEngine
    @Binding var isExpanded: Bool

    var body: some View {
        VStack(spacing: 4) {
            Button(action: { isExpanded.toggle() }) {
                Image(systemName: isExpanded ? "chevron.down" : "chevron.up")
                    .foregroundColor(.white)
                    .padding(8)
                    .background(Color.black.opacity(0.5))
                    .clipShape(Circle())
            }

            if isExpanded || engine.state.activeBoss != nil {
                HStack(spacing: 8) {
                    ForEach(engine.state.unlockedAbilities, id: \ .self) { ability in
                        AbilityButton(engine: engine, ability: ability)
                    }
                }
                .padding(8)
                .background(Color.black.opacity(0.6))
                .cornerRadius(12)
            }
        }
    }
}

struct AbilityButton: View {
    @ObservedObject var engine: GameEngine
    let ability: AbilityID

    var body: some View {
        let isReady = engine.state.abilityCooldowns[ability] == nil || Date() >= engine.state.abilityCooldowns[ability]!
        Button(action: {
            engine.castAbility(ability, now: Date())
        }) {
            ZStack {
                Circle()
                    .fill(isReady ? Color.blue : Color.gray)
                    .frame(width: 44, height: 44)
                Text(ability.displayName.prefix(1))
                    .font(.caption.bold())
                    .foregroundColor(.white)
                if !isReady, let cd = engine.state.abilityCooldowns[ability] {
                    let remaining = cd.timeIntervalSince(Date())
                    Text("\(Int(remaining))")
                        .font(.caption2)
                        .foregroundColor(.white)
                }
            }
        }
        .disabled(!isReady)
    }
}
