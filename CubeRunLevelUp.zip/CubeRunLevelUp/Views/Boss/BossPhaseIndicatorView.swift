import SwiftUI

struct BossPhaseIndicatorView: View {
    let boss: Boss

    var body: some View {
        HStack {
            ForEach(boss.abilities) { ability in
                if let telegraphEnd = ability.nextTelegraphEndsAt {
                    let remaining = max(0, telegraphEnd.timeIntervalSince(Date()))
                    VStack {
                        Text(ability.name)
                            .font(.caption.bold())
                        ProgressBarView(value: remaining, maxValue: ability.telegraphSeconds, foregroundColor: .orange)
                            .frame(width: 80, height: 4)
                    }
                    .padding(4)
                    .background(Color.black.opacity(0.5))
                    .cornerRadius(4)
                }
            }
        }
    }
}
