import SwiftUI

struct BossBattleView: View {
    @ObservedObject var engine: GameEngine
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ZStack {
            Color.black.opacity(0.7).ignoresSafeArea()

            VStack(spacing: 16) {
                if let boss = engine.state.activeBoss {
                    BossHealthBarView(boss: boss)
                    BossPhaseIndicatorView(boss: boss)

                    Spacer()

                    if boss.isEnraged {
                        Text("ENRAGED!")
                            .font(.title.bold())
                            .foregroundColor(.red)
                            .blink()
                    }

                    if let timeRemaining = timeRemaining(for: boss) {
                        Text("Enrage in: \(timeRemaining)s")
                            .font(.caption.bold())
                            .foregroundColor(.orange)
                    }

                    Spacer()

                    AbilityBarView(engine: engine, isExpanded: .constant(true))
                        .padding(.bottom, 20)
                } else {
                    VStack {
                        Text("BOSS DEFEATED!")
                            .font(.largeTitle.bold())
                            .foregroundColor(.yellow)
                        Button("Continue") {
                            dismiss()
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                }
            }
            .padding()
        }
        .onChange(of: engine.state.activeBoss) { newBoss in
            if newBoss == nil {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    dismiss()
                }
            }
        }
    }

    func timeRemaining(for boss: Boss) -> Int? {
        let elapsed = Date().timeIntervalSince(boss.spawnedAt)
        let remaining = Double(boss.enrageTimerSeconds) - elapsed
        return remaining > 0 && remaining < 30 ? Int(remaining) : nil
    }
}

extension View {
    func blink() -> some View {
        self.modifier(BlinkModifier())
    }
}

struct BlinkModifier: ViewModifier {
    @State private var visible = true
    func body(content: Content) -> some View {
        content
            .opacity(visible ? 1 : 0.3)
            .onAppear {
                withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                    visible.toggle()
                }
            }
    }
}
