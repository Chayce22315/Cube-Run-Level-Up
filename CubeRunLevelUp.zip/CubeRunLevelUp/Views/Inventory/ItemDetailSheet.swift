import SwiftUI

struct ItemDetailSheet: View {
    @ObservedObject var engine: GameEngine
    let item: Equipment
    @Environment(\.dismiss) var dismiss

    var body: some View {
        NavigationView {
            VStack(spacing: 16) {
                Text(item.name)
                    .font(.title)
                    .foregroundColor(Color.forRarity(item.rarity))
                Text("Level \(item.itemLevel) \(item.rarity.rawValue.capitalized) \(item.slot.rawValue.capitalized)")

                HStack {
                    Text("\(item.baseStatType.rawValue.capitalized): +\(item.baseStatValue)")
                    if let sec = item.secondaryStatType, let secVal = item.secondaryStatValue {
                        Text("\(sec.rawValue.capitalized): +\(secVal)")
                    }
                }

                Text("Power Score: \(String(format: "%.0f", item.powerScore))")
                    .font(.headline)

                if engine.state.equippedItems[item.slot]?.id != item.id {
                    Button("Equip") {
                        if let old = engine.state.equippedItems[item.slot] {
                            engine.state.inventory.append(old)
                        }
                        engine.state.equippedItems[item.slot] = item
                        engine.state.inventory.removeAll { $0.id == item.id }
                        engine.recomputeMaxHP()
                        dismiss()
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }

                Button("Close") { dismiss() }
                    .padding()
            }
            .navigationTitle("Item Detail")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
