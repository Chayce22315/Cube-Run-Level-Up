import SwiftUI

struct InventoryView: View {
    @ObservedObject var engine: GameEngine
    @State private var selectedSegment = 0
    @State private var selectedItem: Equipment? = nil

    var body: some View {
        NavigationView {
            VStack {
                Picker("", selection: $selectedSegment) {
                    Text("Equipped").tag(0)
                    Text("Inventory").tag(1)
                }
                .pickerStyle(.segmented)
                .padding()

                if selectedSegment == 0 {
                    EquippedView(engine: engine, selectedItem: $selectedItem)
                } else {
                    InventoryGridView(engine: engine, selectedItem: $selectedItem)
                }
            }
            .navigationTitle("Gear")
            .sheet(item: $selectedItem) { item in
                ItemDetailSheet(engine: engine, item: item)
            }
        }
    }
}

struct EquippedView: View {
    @ObservedObject var engine: GameEngine
    @Binding var selectedItem: Equipment?

    var body: some View {
        List(EquipmentSlot.allCases, id: \ .self) { slot in
            HStack {
                Text(slot.rawValue.capitalized)
                Spacer()
                if let item = engine.state.equippedItems[slot] {
                    Text(item.name)
                        .foregroundColor(Color.forRarity(item.rarity))
                        .onTapGesture { selectedItem = item }
                } else {
                    Text("Empty").foregroundColor(.secondary)
                }
            }
        }
    }
}

struct InventoryGridView: View {
    @ObservedObject var engine: GameEngine
    @Binding var selectedItem: Equipment?

    var body: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 80))], spacing: 12) {
                ForEach(engine.state.inventory) { item in
                    VStack {
                        RarityBorderModifier(
                            content: RoundedRectangle(cornerRadius: 8)
                                .fill(Color.gray.opacity(0.2))
                                .frame(width: 70, height: 70)
                                .overlay(Text(item.name.prefix(1)).font(.title)),
                            rarity: item.rarity
                        )
                        Text(item.name)
                            .font(.caption)
                            .lineLimit(1)
                    }
                    .onTapGesture { selectedItem = item }
                }
            }
            .padding()
        }
    }
}
