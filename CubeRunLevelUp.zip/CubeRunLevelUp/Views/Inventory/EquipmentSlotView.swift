import SwiftUI

struct EquipmentSlotView: View {
    let slot: EquipmentSlot
    let item: Equipment?

    var body: some View {
        VStack {
            Text(slot.rawValue.capitalized)
                .font(.caption)
            if let item = item {
                Text(item.name)
                    .font(.caption2)
                    .foregroundColor(Color.forRarity(item.rarity))
            } else {
                Text("Empty")
                    .font(.caption2)
                    .foregroundColor(.secondary)
            }
        }
        .frame(width: 70, height: 70)
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }
}
