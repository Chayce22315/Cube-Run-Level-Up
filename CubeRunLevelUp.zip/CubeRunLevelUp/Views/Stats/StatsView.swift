import SwiftUI

struct StatsView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 16) {
                    Text("Unspent Points: \(engine.state.unspentStatPoints)")
                        .font(.headline)

                    ForEach(StatType.allCases, id: \ .self) { stat in
                        StatRowView(engine: engine, stat: stat)
                    }

                    Divider()

                    CombatSummaryView(engine: engine)
                }
                .padding()
            }
            .navigationTitle("Stats")
        }
    }
}

struct StatRowView: View {
    @ObservedObject var engine: GameEngine
    let stat: StatType

    var currentValue: Int { engine.state.stats.value(for: stat) }

    var body: some View {
        HStack {
            VStack(alignment: .leading) {
                Text(stat.rawValue.capitalized)
                    .font(.subheadline.bold())
                Text(derivedDescription)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Text("\(currentValue)/100")
                .font(.caption)
            Stepper("") {
                allocate(1)
            } onDecrement: {
                // No respec in v1
            }
            .labelsHidden()
            Button("Max") {
                allocate(engine.state.unspentStatPoints)
            }
            .font(.caption)
            .disabled(engine.state.unspentStatPoints <= 0)
        }
        .padding()
        .background(Color.gray.opacity(0.1))
        .cornerRadius(8)
    }

    func allocate(_ points: Int) {
        let applied = engine.state.stats.allocate(stat, points: min(points, engine.state.unspentStatPoints))
        engine.state.unspentStatPoints -= applied
        engine.recomputeMaxHP()
    }

    var derivedDescription: String {
        switch stat {
        case .strength: return "Atk: \(Int(engine.calculatePlayerAttack())), Crit Dmg: \(Int(engine.calculateCritDamage()*100))%"
        case .defense: return "Def: \(Int(engine.calculateDefense()))"
        case .vitality: return "HP: \(Int(engine.state.maxHP)), Regen: \(String(format: "%.1f", 1 + Double(currentValue)*0.5))/s"
        case .agility: return "Speed: \(String(format: "%.2f", 1 + Double(currentValue)*0.05))/s, Crit: \(String(format: "%.1f", engine.calculateCritChance()*100))%, Dodge: \(String(format: "%.1f", engine.calculateDodgeChance()*100))%"
        case .intelligence: return "Coin: +\(String(format: "%.0f", engine.calculateCoinBonus()*100-100))%, XP: +\(String(format: "%.0f", engine.calculateXPBonus()*100-100))%"
        }
    }
}

struct CombatSummaryView: View {
    @ObservedObject var engine: GameEngine

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Combat Summary")
                .font(.headline)
            Text("Attack: \(Int(engine.calculatePlayerAttack()))")
            Text("Defense: \(Int(engine.calculateDefense()))")
            Text("Max HP: \(Int(engine.state.maxHP))")
            Text("Crit Rate: \(String(format: "%.1f", engine.calculateCritChance()*100))%")
            Text("Dodge Rate: \(String(format: "%.1f", engine.calculateDodgeChance()*100))%")
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding()
        .background(Color.blue.opacity(0.1))
        .cornerRadius(8)
    }
}
