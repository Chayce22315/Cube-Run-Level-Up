import Foundation

class LocalizationService {
    static let shared = LocalizationService()
    private init() {}

    func localized(_ key: String) -> String {
        // In real app, uses NSLocalizedString with custom bundle logic
        NSLocalizedString(key, comment: "")
    }
}
