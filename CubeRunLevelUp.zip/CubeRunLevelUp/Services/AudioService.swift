import Foundation
import AVFoundation

class AudioService: ObservableObject {
    static let shared = AudioService()
    private init() {}

    private var players: [String: AVAudioPlayer] = [:]
    private var musicPlayer: AVAudioPlayer?

    @Published var masterVolume: Double = 0.8
    @Published var musicVolume: Double = 0.7
    @Published var sfxVolume: Double = 1.0

    func playSFX(named: String) {
        guard sfxVolume > 0 else { return }
        // Placeholder: actual implementation would load from bundle
    }

    func playMusic(named: String) {
        guard musicVolume > 0 else { return }
        // Placeholder
    }

    func stopMusic() {
        musicPlayer?.stop()
    }
}
