import Foundation

struct AnalyticsEvent: Codable {
    let name: String
    let timestamp: Date
    let parameters: [String: String]
}

class AnalyticsService: ObservableObject {
    static let shared = AnalyticsService()
    private init() {}

    @Published var events: [AnalyticsEvent] = []
    @Published var isEnabled = true

    func log(_ name: String, parameters: [String: String] = [:]) {
        guard isEnabled else { return }
        events.append(AnalyticsEvent(name: name, timestamp: Date(), parameters: parameters))
    }

    func export() -> Data? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = .prettyPrinted
        return try? encoder.encode(events)
    }

    func clear() {
        events.removeAll()
    }
}
