import Foundation

class ErrorReportingService {
    static let shared = ErrorReportingService()
    private init() {}

    private var logFileURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("errors.log")
    }

    func log(_ entry: ErrorLogEntry) {
        var entries = loadAll()
        entries.append(entry)
        if entries.count > 500 { entries.removeFirst(entries.count - 500) }
        save(entries)
    }

    func loadAll() -> [ErrorLogEntry] {
        guard let data = try? Data(contentsOf: logFileURL) else { return [] }
        let lines = data.split(separator: 10) // newline
        return lines.compactMap { line in
            try? JSONDecoder().decode(ErrorLogEntry.self, from: Data(line))
        }
    }

    private func save(_ entries: [ErrorLogEntry]) {
        let data = entries.compactMap { try? JSONEncoder().encode($0) }
            .map { String(data: $0, encoding: .utf8)! }
            .joined(separator: "\n")
            .data(using: .utf8)
        try? data?.write(to: logFileURL)
    }

    func attemptAutoUpload() {
        // No-op: no backend configured for sideloaded IPA
        log(ErrorLogEntry(id: UUID(), severity: .minor, message: "Auto-upload not configured", context: "ErrorReportingService", timestamp: Date(), stackSummary: nil))
    }
}
