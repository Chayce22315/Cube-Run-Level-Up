import Foundation
import UserNotifications

class NotificationService {
    static let shared = NotificationService()
    private init() {}

    private var sentCount = 0
    private var lastReset = Date()

    func requestPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .badge, .sound]) { _, _ in }
    }

    func scheduleBossAvailable() {
        guard canSend() else { return }
        let content = UNMutableNotificationContent()
        content.title = "Boss Available!"
        content.body = "A boss is waiting for you in Cube Run."
        content.sound = .default
        let request = UNNotificationRequest(identifier: "boss", content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
        sentCount += 1
    }

    func scheduleOfflineEarnings() {
        guard canSend() else { return }
        let content = UNMutableNotificationContent()
        content.title = "Offline Earnings Ready"
        content.body = "Your cube has been busy while you were away."
        content.sound = .default
        let request = UNNotificationRequest(identifier: "offline", content: content, trigger: nil)
        UNUserNotificationCenter.current().add(request)
        sentCount += 1
    }

    private func canSend() -> Bool {
        if Date().timeIntervalSince(lastReset) >= 86400 {
            sentCount = 0
            lastReset = Date()
        }
        return sentCount < 2
    }
}
