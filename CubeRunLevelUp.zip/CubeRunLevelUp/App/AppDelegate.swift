import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        return true
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        // Background task for save flush
        var bgTask = UIBackgroundTaskIdentifier.invalid
        bgTask = application.beginBackgroundTask(withName: "SaveFlush") {
            application.endBackgroundTask(bgTask)
            bgTask = .invalid
        }
        DispatchQueue.global().async {
            // Save already handled in scenePhase change
            application.endBackgroundTask(bgTask)
            bgTask = .invalid
        }
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Final save attempt
    }
}
