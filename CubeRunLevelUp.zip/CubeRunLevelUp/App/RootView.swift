import SwiftUI

struct RootView: View {
    @StateObject var engine: GameEngine
    @State private var selectedTab = 0
    @State private var showOfflineSummary = false
    @State private var offlineSummary: OfflineSummary? = nil
    @State private var showBossBattle = false

    init(engine: GameEngine) {
        _engine = StateObject(wrappedValue: engine)
    }

    var body: some View {
        ZStack {
            TabView(selection: $selectedTab) {
                MainGameView(engine: engine)
                    .tabItem { Image(systemName: "figure.run"); Text("Run") }
                    .tag(0)
                StatsView(engine: engine)
                    .tabItem { Image(systemName: "chart.bar.fill"); Text("Stats") }
                    .tag(1)
                InventoryView(engine: engine)
                    .tabItem { Image(systemName: "shield.fill"); Text("Gear") }
                    .tag(2)
                QuestsView(engine: engine)
                    .tabItem { Image(systemName: "list.bullet.clipboard"); Text("Quests") }
                    .tag(3)
                AchievementsView(engine: engine)
                    .tabItem { Image(systemName: "trophy.fill"); Text("Trophy") }
                    .tag(4)
                CosmeticsView(engine: engine)
                    .tabItem { Image(systemName: "sparkles"); Text("Cosmetics") }
                    .tag(5)
                PrestigeView(engine: engine)
                    .tabItem { Image(systemName: "arrow.triangle.2.circlepath"); Text("Prestige") }
                    .tag(6)
                SettingsView(engine: engine)
                    .tabItem { Image(systemName: "gearshape.fill"); Text("Settings") }
                    .tag(7)
            }
            .onAppear {
                checkOfflineProgress()
                engine.start()
                if engine.state.settings.save.autoSaveEnabled {
                    SaveManager.shared.startAutoSave(every: engine.state.settings.save.autoSaveFrequencySeconds, engine: engine)
                }
            }
            .fullScreenCover(isPresented: $showBossBattle) {
                BossBattleView(engine: engine)
            }
            .fullScreenCover(isPresented: $showOfflineSummary) {
                if let summary = offlineSummary {
                    OfflineSummaryView(summary: summary) {
                        showOfflineSummary = false
                    }
                }
            }
        }
        .onChange(of: engine.state.activeBoss) { boss in
            showBossBattle = boss != nil
        }
    }

    func checkOfflineProgress() {
        let now = Date()
        let elapsed = now.timeIntervalSince(engine.state.lastActiveAt)
        guard elapsed > 60 else { return }
        let calc = OfflineProgressCalculator()
        offlineSummary = calc.simulateOffline(from: engine.state.lastActiveAt, to: now, engine: engine)
        showOfflineSummary = true
    }
}
