import SwiftUI

@main
struct CubeRunLevelUpApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @Environment(\.scenePhase) var scenePhase

    @StateObject private var engine = GameEngine(state: SaveManager.shared.load())

    var body: some Scene {
        WindowGroup {
            RootView(engine: engine)
                .onChange(of: scenePhase) { phase in
                    switch phase {
                    case .background, .inactive:
                        SaveManager.shared.save(state: engine.state)
                        engine.stop()
                    case .active:
                        engine.start()
                    @unknown default:
                        break
                    }
                }
        }
    }
}
