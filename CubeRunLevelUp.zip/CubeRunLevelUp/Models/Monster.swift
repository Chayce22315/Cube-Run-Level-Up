import Foundation

struct Monster: Codable, Identifiable {
    let id: UUID
    var type: MonsterType
    var maxHP: Double
    var currentHP: Double
    var damage: Double
    var spawnDistance: Double

    static func spawn(atDistance distance: Double, monsterID: UUID = UUID()) -> Monster {
        let type = MonsterType.randomForDistance(distance)
        let hp = 10 + distance / 100
        let dmg = 5 + distance / 200
        return Monster(id: monsterID, type: type, maxHP: hp, currentHP: hp, damage: dmg, spawnDistance: distance)
    }
}

enum MonsterType: String, Codable, CaseIterable {
    case slime, goblin, bat, skeleton, wraith, golem

    static func randomForDistance(_ distance: Double) -> MonsterType {
        let tierIndex = min(Int(distance / 500), MonsterType.allCases.count - 1)
        let available = Array(MonsterType.allCases.prefix(tierIndex + 1))
        return available.randomElement() ?? .slime
    }
}
