import Foundation

struct Equipment: Codable, Identifiable, Equatable {
    let id: UUID
    var slot: EquipmentSlot
    var rarity: EquipmentRarity
    var itemLevel: Int
    var baseStatType: StatType
    var baseStatValue: Int
    var secondaryStatType: StatType?
    var secondaryStatValue: Int?
    var name: String

    var powerScore: Double {
        Double(baseStatValue) * rarity.scoreMultiplier + Double(secondaryStatValue ?? 0) * rarity.scoreMultiplier * 0.5
    }
}

enum EquipmentSlot: String, Codable, CaseIterable {
    case weapon, armor, helmet, boots, accessory
}

enum EquipmentRarity: String, Codable, CaseIterable {
    case common, uncommon, rare, epic, legendary

    var scoreMultiplier: Double {
        switch self {
        case .common: return 1.0
        case .uncommon: return 1.5
        case .rare: return 2.25
        case .epic: return 3.4
        case .legendary: return 5.0
        }
    }

    var dropWeight: Double {
        switch self {
        case .common: return 60
        case .uncommon: return 25
        case .rare: return 10
        case .epic: return 4
        case .legendary: return 1
        }
    }

    var colorHex: String {
        switch self {
        case .common: return "#9E9E9E"
        case .uncommon: return "#4CAF50"
        case .rare: return "#2196F3"
        case .epic: return "#9C27B0"
        case .legendary: return "#FF9800"
        }
    }
}
