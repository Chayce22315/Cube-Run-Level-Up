import Foundation

struct PlayerStats: Codable {
    var strength: Int = 0
    var defense: Int = 0
    var vitality: Int = 0
    var agility: Int = 0
    var intelligence: Int = 0

    static let maxPerStat = 100

    mutating func allocate(_ stat: StatType, points: Int) -> Int {
        let current = value(for: stat)
        let applied = min(points, Self.maxPerStat - current)
        guard applied > 0 else { return 0 }
        set(stat, to: current + applied)
        return applied
    }

    func value(for stat: StatType) -> Int {
        switch stat {
        case .strength: return strength
        case .defense: return defense
        case .vitality: return vitality
        case .agility: return agility
        case .intelligence: return intelligence
        }
    }

    private mutating func set(_ stat: StatType, to value: Int) {
        switch stat {
        case .strength: strength = value
        case .defense: defense = value
        case .vitality: vitality = value
        case .agility: agility = value
        case .intelligence: intelligence = value
        }
    }
}

enum StatType: String, Codable, CaseIterable {
    case strength, defense, vitality, agility, intelligence
}
