import Foundation

enum CosmeticSlotType: String, Codable, CaseIterable {
    case skin, trail, aura, effect, title
}

enum CosmeticID: String, Codable, CaseIterable {
    case defaultCube, skinLava, skinCrystal, skinShadow, skinGold, skinRainbow, skinVoid
    case noTrail, trailFire, trailIce, trailStar, trailSmoke, trailRainbow, trailVoid
    case noAura, auraGoldGlow, auraPurpleGlow, auraRedGlow, auraLightning, auraHoly
    case effectDefault, effectFire, effectIce, effectHoly, effectVoid
    case titleNovice, titleRunner, titleChampion, titleLegend, titleAscended, titleEternal

    var slot: CosmeticSlotType {
        switch self {
        case .defaultCube, .skinLava, .skinCrystal, .skinShadow, .skinGold, .skinRainbow, .skinVoid:
            return .skin
        case .noTrail, .trailFire, .trailIce, .trailStar, .trailSmoke, .trailRainbow, .trailVoid:
            return .trail
        case .noAura, .auraGoldGlow, .auraPurpleGlow, .auraRedGlow, .auraLightning, .auraHoly:
            return .aura
        case .effectDefault, .effectFire, .effectIce, .effectHoly, .effectVoid:
            return .effect
        case .titleNovice, .titleRunner, .titleChampion, .titleLegend, .titleAscended, .titleEternal:
            return .title
        }
    }

    var displayName: String {
        switch self {
        case .defaultCube: return "Default Cube"
        case .skinLava: return "Lava Cube"
        case .skinCrystal: return "Crystal Cube"
        case .skinShadow: return "Shadow Cube"
        case .skinGold: return "Gold Cube"
        case .skinRainbow: return "Rainbow Cube"
        case .skinVoid: return "Void Cube"
        case .noTrail: return "No Trail"
        case .trailFire: return "Fire Trail"
        case .trailIce: return "Ice Trail"
        case .trailStar: return "Star Trail"
        case .trailSmoke: return "Smoke Trail"
        case .trailRainbow: return "Rainbow Trail"
        case .trailVoid: return "Void Trail"
        case .noAura: return "No Aura"
        case .auraGoldGlow: return "Gold Glow"
        case .auraPurpleGlow: return "Purple Glow"
        case .auraRedGlow: return "Red Glow"
        case .auraLightning: return "Lightning"
        case .auraHoly: return "Holy"
        case .effectDefault: return "Default"
        case .effectFire: return "Fire"
        case .effectIce: return "Ice"
        case .effectHoly: return "Holy"
        case .effectVoid: return "Void"
        case .titleNovice: return "Novice"
        case .titleRunner: return "Runner"
        case .titleChampion: return "Champion"
        case .titleLegend: return "Legend"
        case .titleAscended: return "Ascended"
        case .titleEternal: return "Eternal"
        }
    }
}

struct EquippedCosmetics: Codable {
    var skin: CosmeticID = .defaultCube
    var trail: CosmeticID = .noTrail
    var aura: CosmeticID = .noAura
    var effect: CosmeticID = .effectDefault
    var title: CosmeticID = .titleNovice
}

struct CosmeticSet: Codable {
    var theme: CosmeticTheme
    var pieces: [CosmeticID]
    var bonusDescriptionKey: String
    var bonusStatType: StatType
    var bonusFlatValue: Int
}

enum CosmeticTheme: String, Codable, CaseIterable {
    case lava, crystal, shadow, gold, rainbow, void

    var skin: CosmeticID {
        switch self {
        case .lava: return .skinLava
        case .crystal: return .skinCrystal
        case .shadow: return .skinShadow
        case .gold: return .skinGold
        case .rainbow: return .skinRainbow
        case .void: return .skinVoid
        }
    }

    var trail: CosmeticID {
        switch self {
        case .lava: return .trailFire
        case .crystal: return .trailIce
        case .shadow: return .trailSmoke
        case .gold: return .trailFire
        case .rainbow: return .trailRainbow
        case .void: return .trailVoid
        }
    }

    var aura: CosmeticID {
        switch self {
        case .lava: return .auraRedGlow
        case .crystal: return .auraPurpleGlow
        case .shadow: return .auraPurpleGlow
        case .gold: return .auraGoldGlow
        case .rainbow: return .auraHoly
        case .void: return .auraHoly
        }
    }

    var setBonus: (stat: StatType, value: Int) {
        switch self {
        case .lava: return (.strength, 10)
        case .crystal: return (.defense, 10)
        case .shadow: return (.agility, 10)
        case .gold: return (.intelligence, 15)
        case .rainbow: return (.strength, 10)
        case .void: return (.intelligence, 10)
        }
    }
}
