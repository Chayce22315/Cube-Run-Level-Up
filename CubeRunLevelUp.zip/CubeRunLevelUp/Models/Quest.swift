import Foundation

struct Quest: Codable, Identifiable {
    let id: UUID
    var definitionID: QuestDefinitionID
    var kind: QuestKind
    var progressTarget: Double
    var currentProgress: Double = 0
    var rewardCoins: Int64
    var rewardGems: Int64
    var isClaimed: Bool = false

    var isComplete: Bool { currentProgress >= progressTarget }
}

enum QuestKind: String, Codable { case daily, weekly }

enum QuestDefinitionID: String, Codable, CaseIterable {
    case runDistance, defeatMonsters, defeatBosses, earnCoins, levelUp,
         useAbilities, equipItems, prestigeOnce, collectGems, surviveNoDeath

    var displayName: String {
        switch self {
        case .runDistance: return "Run Distance"
        case .defeatMonsters: return "Defeat Monsters"
        case .defeatBosses: return "Defeat Bosses"
        case .earnCoins: return "Earn Coins"
        case .levelUp: return "Level Up"
        case .useAbilities: return "Use Abilities"
        case .equipItems: return "Equip Items"
        case .prestigeOnce: return "Prestige"
        case .collectGems: return "Collect Gems"
        case .surviveNoDeath: return "Survive Without Dying"
        }
    }
}
