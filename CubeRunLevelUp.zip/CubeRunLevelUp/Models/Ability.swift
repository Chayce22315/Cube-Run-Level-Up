import Foundation

enum AbilityID: String, Codable, CaseIterable {
    case powerStrike
    case shieldWall
    case adrenaline
    case vampiricTouch
    case whirlwind
    case fortify
    case timeWarp
    case cubeRage

    var unlockLevel: Int {
        switch self {
        case .powerStrike: return 1
        case .shieldWall: return 5
        case .adrenaline: return 10
        case .vampiricTouch: return 15
        case .whirlwind: return 20
        case .fortify: return 30
        case .timeWarp: return 40
        case .cubeRage: return 50
        }
    }

    var cooldownSeconds: Double {
        switch self {
        case .powerStrike: return 8
        case .shieldWall: return 15
        case .adrenaline: return 20
        case .vampiricTouch: return 18
        case .whirlwind: return 12
        case .fortify: return 25
        case .timeWarp: return 45
        case .cubeRage: return 60
        }
    }

    var durationSeconds: Double? {
        switch self {
        case .powerStrike: return nil
        case .shieldWall: return 5
        case .adrenaline: return 8
        case .vampiricTouch: return 6
        case .whirlwind: return nil
        case .fortify: return 6
        case .timeWarp: return 10
        case .cubeRage: return 8
        }
    }

    var displayName: String {
        switch self {
        case .powerStrike: return "Power Strike"
        case .shieldWall: return "Shield Wall"
        case .adrenaline: return "Adrenaline"
        case .vampiricTouch: return "Vampiric Touch"
        case .whirlwind: return "Whirlwind"
        case .fortify: return "Fortify"
        case .timeWarp: return "Time Warp"
        case .cubeRage: return "Cube Rage"
        }
    }

    var description: String {
        switch self {
        case .powerStrike: return "Next attack deals 300% damage"
        case .shieldWall: return "Incoming damage reduced 50% for 5s"
        case .adrenaline: return "Attack speed +75% for 8s"
        case .vampiricTouch: return "Heal 20% of damage dealt for 6s"
        case .whirlwind: return "Deals 150% damage to current target"
        case .fortify: return "Damage reduced 75%, Attack -25% for 6s"
        case .timeWarp: return "Ability cooldowns tick 3x speed for 10s"
        case .cubeRage: return "Attack +100%, Speed +50%, Heal 5% HP/s for 8s"
        }
    }

    var isHealCapable: Bool {
        self == .vampiricTouch || self == .cubeRage
    }
}
