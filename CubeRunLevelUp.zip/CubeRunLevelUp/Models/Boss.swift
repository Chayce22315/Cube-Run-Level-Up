import Foundation

struct Boss: Codable, Identifiable, Equatable {
    let id: UUID
    var number: Int
    var maxHP: Double
    var currentHP: Double
    var damage: Double
    var phase: Int = 1
    var abilities: [BossAbility]
    var spawnedAt: Date
    var enrageTimerSeconds: Int = 90
    var isEnraged: Bool = false

    static func spawn(number: Int) -> Boss {
        let hp = 500 * pow(1.15, Double(number - 1))
        let dmg = 50 * pow(1.15, Double(number - 1))
        return Boss(
            id: UUID(),
            number: number,
            maxHP: hp,
            currentHP: hp,
            damage: dmg,
            abilities: BossAbility.abilities(forBossNumber: number),
            spawnedAt: Date()
        )
    }

    mutating func updatePhase() {
        let pct = currentHP / maxHP
        if pct > 0.66 { phase = 1 }
        else if pct > 0.33 { phase = 2 }
        else { phase = 3 }
    }

    var phaseDamageMultiplier: Double {
        switch phase {
        case 2: return 1.15
        case 3: return 1.30
        default: return 1.0
        }
    }

    var phaseAttackSpeedMultiplier: Double {
        return phase == 3 ? 1.20 : 1.0
    }
}

struct BossAbility: Codable, Identifiable, Equatable {
    let id: UUID
    var name: String
    var telegraphSeconds: Double
    var cooldownSeconds: Double
    var effect: BossAbilityEffect
    var lastUsedAt: Date? = nil
    var nextTelegraphEndsAt: Date? = nil

    static func abilities(forBossNumber number: Int) -> [BossAbility] {
        var list = [BossAbility(id: UUID(), name: "Slam", telegraphSeconds: 1.2, cooldownSeconds: 6, effect: .directDamage(multiplier: 1.5))]
        if number >= 3 {
            list.append(BossAbility(id: UUID(), name: "Enrage Pulse", telegraphSeconds: 1.5, cooldownSeconds: 12, effect: .damageOverTime(multiplier: 0.3, ticks: 3)))
        }
        if number >= 6 {
            list.append(BossAbility(id: UUID(), name: "Void Zone", telegraphSeconds: 2.0, cooldownSeconds: 18, effect: .directDamage(multiplier: 2.5)))
        }
        return list
    }
}

enum BossAbilityEffect: Codable, Equatable {
    case directDamage(multiplier: Double)
    case damageOverTime(multiplier: Double, ticks: Int)
}
