import Foundation

enum ErrorSeverity: String, Codable {
    case minor, warning, critical, fatal
}

struct ErrorLogEntry: Codable, Identifiable {
    let id: UUID
    var severity: ErrorSeverity
    var message: String
    var context: String
    var timestamp: Date
    var stackSummary: String?
}
