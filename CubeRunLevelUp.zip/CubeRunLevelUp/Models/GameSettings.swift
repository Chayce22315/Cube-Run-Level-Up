import Foundation

struct GameSettings: Codable {
    var gameplay: GameplaySettings = GameplaySettings()
    var graphics: GraphicsPreset = .optimized
    var audio: AudioSettings = AudioSettings()
    var save: SaveSettings = SaveSettings()
    var notifications: NotificationSettings = NotificationSettings()
    var analytics: AnalyticsSettings = AnalyticsSettings()
    var languageOverride: String? = nil
}

struct GameplaySettings: Codable {
    var manualTapAttacks: Bool = true
    var autoAbilities: Bool = true
    var autoCollect: Bool = true
    var autoLevelUp: Bool = true
    var autoEquip: Bool = true
    var autoHealThreshold: Double = 0.3
}

enum GraphicsPreset: String, Codable, CaseIterable {
    case extremelyLow = "Extremely Low"
    case lame = "Lame"
    case optimized = "Optimized"
    case performance = "Performance"
    case high = "High"
    case crazy = "Crazy"
}

struct AudioSettings: Codable {
    var masterVolume: Double = 0.8
    var musicVolume: Double = 0.7
    var sfxVolume: Double = 1.0
    var hapticsEnabled: Bool = true
    var backgroundAudio: Bool = false
}

struct SaveSettings: Codable {
    var autoSaveEnabled: Bool = true
    var autoSaveFrequencySeconds: Double = 10
    var iCloudSyncEnabled: Bool = false
}

struct NotificationSettings: Codable {
    var enabled: Bool = false
    var bossAvailable: Bool = true
    var offlineEarningsReady: Bool = true
}

struct AnalyticsSettings: Codable {
    var enabled: Bool = true
}
