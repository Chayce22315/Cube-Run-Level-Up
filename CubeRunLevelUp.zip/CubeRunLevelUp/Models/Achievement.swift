import Foundation

enum AchievementCategory: String, Codable, CaseIterable {
    case distance, combat, leveling, bosses, prestige,
         collection, wealth, survival, cosmetics, dedication
}

enum AchievementID: String, Codable, CaseIterable {
    case distance1, distance2, distance3, distance4, distance5
    case combat1, combat2, combat3, combat4, combat5
    case leveling1, leveling2, leveling3, leveling4, leveling5
    case bosses1, bosses2, bosses3, bosses4, bosses5
    case prestige1, prestige2, prestige3, prestige4, prestige5
    case collection1, collection2, collection3, collection4, collection5
    case wealth1, wealth2, wealth3, wealth4, wealth5
    case survival1, survival2, survival3, survival4, survival5
    case cosmetics1, cosmetics2, cosmetics3, cosmetics4
    case dedication1, dedication2, dedication3, dedication4
    case completionist

    var category: AchievementCategory {
        switch self {
        case .distance1, .distance2, .distance3, .distance4, .distance5: return .distance
        case .combat1, .combat2, .combat3, .combat4, .combat5: return .combat
        case .leveling1, .leveling2, .leveling3, .leveling4, .leveling5: return .leveling
        case .bosses1, .bosses2, .bosses3, .bosses4, .bosses5: return .bosses
        case .prestige1, .prestige2, .prestige3, .prestige4, .prestige5: return .prestige
        case .collection1, .collection2, .collection3, .collection4, .collection5: return .collection
        case .wealth1, .wealth2, .wealth3, .wealth4, .wealth5: return .wealth
        case .survival1, .survival2, .survival3, .survival4, .survival5: return .survival
        case .cosmetics1, .cosmetics2, .cosmetics3, .cosmetics4: return .cosmetics
        case .dedication1, .dedication2, .dedication3, .dedication4: return .dedication
        case .completionist: return .dedication
        }
    }

    var title: String {
        switch self {
        case .distance1: return "First Steps"
        case .distance2: return "Marathoner"
        case .distance3: return "Ultra Runner"
        case .distance4: return "World Circler"
        case .distance5: return "Beyond the Horizon"
        case .combat1: return "First Blood"
        case .combat2: return "Monster Hunter"
        case .combat3: return "Slayer"
        case .combat4: return "Exterminator"
        case .combat5: return "Apex Predator"
        case .leveling1: return "Getting Started"
        case .leveling2: return "Rising Star"
        case .leveling3: return "Veteran"
        case .leveling4: return "Master"
        case .leveling5: return "Grandmaster"
        case .bosses1: return "Boss Slayer"
        case .bosses2: return "Boss Hunter"
        case .bosses3: return "Boss Crusher"
        case .bosses4: return "Boss Nightmare"
        case .bosses5: return "Enrage Survivor"
        case .prestige1: return "New Beginning"
        case .prestige2: return "Cycle Runner"
        case .prestige3: return "Reborn"
        case .prestige4: return "Ascendant"
        case .prestige5: return "Eternal"
        case .collection1: return "First Find"
        case .collection2: return "Collector"
        case .collection3: return "Hoarder"
        case .collection4: return "Legendary Find"
        case .collection5: return "Full Set"
        case .wealth1: return "Pocket Change"
        case .wealth2: return "Coin Purse"
        case .wealth3: return "Rich"
        case .wealth4: return "Wealthy"
        case .wealth5: return "Coin Capped"
        case .survival1: return "Close Call"
        case .survival2: return "Iron Will"
        case .survival3: return "Unbreakable"
        case .survival4: return "Untouchable"
        case .survival5: return "Comeback King"
        case .cosmetics1: return "Dress Up"
        case .cosmetics2: return "Fashionista"
        case .cosmetics3: return "Trendsetter"
        case .cosmetics4: return "Full Wardrobe"
        case .dedication1: return "Welcome Back"
        case .dedication2: return "Regular"
        case .dedication3: return "Devoted"
        case .dedication4: return "Loyalist"
        case .completionist: return "Completionist"
        }
    }

    var threshold: Double {
        switch self {
        case .distance1: return 100
        case .distance2: return 10_000
        case .distance3: return 100_000
        case .distance4: return 1_000_000
        case .distance5: return 10_000_000
        case .combat1: return 1
        case .combat2: return 1_000
        case .combat3: return 25_000
        case .combat4: return 250_000
        case .combat5: return 1_000_000
        case .leveling1: return 5
        case .leveling2: return 25
        case .leveling3: return 50
        case .leveling4: return 75
        case .leveling5: return 100
        case .bosses1: return 1
        case .bosses2: return 10
        case .bosses3: return 50
        case .bosses4: return 200
        case .bosses5: return 1
        case .prestige1: return 1
        case .prestige2: return 5
        case .prestige3: return 15
        case .prestige4: return 50
        case .prestige5: return 100
        case .collection1: return 1
        case .collection2: return 100
        case .collection3: return 1_000
        case .collection4: return 1
        case .collection5: return 1
        case .wealth1: return 10_000
        case .wealth2: return 1_000_000
        case .wealth3: return 100_000_000
        case .wealth4: return 1_000_000_000
        case .wealth5: return 2_147_483_647
        case .survival1: return 1
        case .survival2: return 1
        case .survival3: return 1
        case .survival4: return 1
        case .survival5: return 1
        case .cosmetics1: return 1
        case .cosmetics2: return 10
        case .cosmetics3: return 25
        case .cosmetics4: return 1
        case .dedication1: return 2
        case .dedication2: return 7
        case .dedication3: return 30
        case .dedication4: return 100
        case .completionist: return 48
        }
    }

    var rewardGems: Int64 {
        switch self {
        case .distance1, .combat1, .leveling1, .collection1, .wealth1: return 5
        case .distance2, .combat2, .leveling2, .collection2, .wealth2: return 15
        case .distance3, .combat3, .leveling3, .collection3, .wealth3: return 30
        case .distance4, .combat4, .leveling4, .collection4, .wealth4: return 75
        case .distance5, .combat5, .leveling5, .wealth5: return 150
        case .bosses1: return 10
        case .bosses2: return 25
        case .bosses3: return 50
        case .bosses4: return 100
        case .bosses5: return 40
        case .prestige1: return 20
        case .prestige2: return 40
        case .prestige3: return 80
        case .prestige4: return 150
        case .prestige5: return 300
        case .survival1: return 10
        case .survival2: return 15
        case .survival3: return 35
        case .survival4: return 60
        case .survival5: return 25
        case .cosmetics1: return 5
        case .cosmetics2: return 20
        case .cosmetics3: return 40
        case .cosmetics4: return 100
        case .dedication1: return 5
        case .dedication2: return 20
        case .dedication3: return 60
        case .dedication4: return 150
        case .completionist: return 500
        }
    }

    var description: String {
        switch self {
        case .distance1: return "Run 100 meters (lifetime)"
        case .distance2: return "Run 10,000 meters (lifetime)"
        case .distance3: return "Run 100,000 meters (lifetime)"
        case .distance4: return "Run 1,000,000 meters (lifetime)"
        case .distance5: return "Run 10,000,000 meters (lifetime)"
        case .combat1: return "Defeat 1 monster"
        case .combat2: return "Defeat 1,000 monsters (lifetime)"
        case .combat3: return "Defeat 25,000 monsters (lifetime)"
        case .combat4: return "Defeat 250,000 monsters (lifetime)"
        case .combat5: return "Defeat 1,000,000 monsters (lifetime)"
        case .leveling1: return "Reach level 5"
        case .leveling2: return "Reach level 25"
        case .leveling3: return "Reach level 50"
        case .leveling4: return "Reach level 75"
        case .leveling5: return "Reach level 100 in a single prestige run"
        case .bosses1: return "Defeat 1 boss"
        case .bosses2: return "Defeat 10 bosses (lifetime)"
        case .bosses3: return "Defeat 50 bosses (lifetime)"
        case .bosses4: return "Defeat 200 bosses (lifetime)"
        case .bosses5: return "Defeat an enraged boss"
        case .prestige1: return "Prestige once"
        case .prestige2: return "Prestige 5 times"
        case .prestige3: return "Prestige 15 times"
        case .prestige4: return "Prestige 50 times"
        case .prestige5: return "Prestige 100 times"
        case .collection1: return "Equip your first item"
        case .collection2: return "Collect 100 items (lifetime)"
        case .collection3: return "Collect 1,000 items (lifetime)"
        case .collection4: return "Obtain a Legendary item"
        case .collection5: return "Fill all 5 equipment slots with Epic+ items"
        case .wealth1: return "Earn 10,000 coins (lifetime)"
        case .wealth2: return "Earn 1,000,000 coins (lifetime)"
        case .wealth3: return "Earn 100,000,000 coins (lifetime)"
        case .wealth4: return "Earn 1,000,000,000 coins (lifetime)"
        case .wealth5: return "Reach the coin cap at once"
        case .survival1: return "Survive a fight dropping below 10% HP"
        case .survival2: return "Go 10 minutes without dying"
        case .survival3: return "Go 60 minutes without dying"
        case .survival4: return "Defeat a boss without taking damage"
        case .survival5: return "Defeat a boss after dying once during that fight"
        case .cosmetics1: return "Equip any non-default cosmetic"
        case .cosmetics2: return "Unlock 10 cosmetics"
        case .cosmetics3: return "Unlock 25 cosmetics"
        case .cosmetics4: return "Unlock every cosmetic"
        case .dedication1: return "Log in on 2 different days"
        case .dedication2: return "Log in on 7 different days"
        case .dedication3: return "Log in on 30 different days"
        case .dedication4: return "Log in on 100 different days"
        case .completionist: return "Unlock all other 48 achievements"
        }
    }
}
