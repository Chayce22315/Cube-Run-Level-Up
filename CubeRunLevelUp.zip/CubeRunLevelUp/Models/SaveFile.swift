import Foundation
import CryptoKit

struct SaveFile: Codable {
    var state: GameState
    var checksum: String
    var writtenAt: Date
}

extension Data {
    var sha256Hex: String {
        SHA256.hash(data: self).compactMap { String(format: "%02x", $0) }.joined()
    }
}
