import Foundation

enum CurrencyType: String, Codable {
    case coins, gems, souls
}

struct PermanentBonuses: Codable {
    var coinMultiplierLevel: Int = 0
    var xpMultiplierLevel: Int = 0
    var startingDistanceLevel: Int = 0
    var damageMultiplierLevel: Int = 0
    var offlineEfficiencyLevel: Int = 0

    var coinMultiplier: Double { 1.0 + Double(coinMultiplierLevel) * 0.05 }
    var xpMultiplier: Double { 1.0 + Double(xpMultiplierLevel) * 0.05 }
    var startingDistance: Double { Double(startingDistanceLevel) * 50 }
    var damageMultiplier: Double { 1.0 + Double(damageMultiplierLevel) * 0.03 }
    var offlineEfficiency: Double { min(1.0, 0.5 + Double(offlineEfficiencyLevel) * 0.02) }

    func costForNextLevel(of type: BonusType) -> Int64 {
        switch type {
        case .coinMultiplier: return Int64(10 * (coinMultiplierLevel + 1))
        case .xpMultiplier: return Int64(10 * (xpMultiplierLevel + 1))
        case .startingDistance: return Int64(25 * (startingDistanceLevel + 1))
        case .damageMultiplier: return Int64(15 * (damageMultiplierLevel + 1))
        case .offlineEfficiency: return Int64(30 * (offlineEfficiencyLevel + 1))
        }
    }

    func maxLevel(for type: BonusType) -> Int {
        switch type {
        case .coinMultiplier: return 50
        case .xpMultiplier: return 50
        case .startingDistance: return 20
        case .damageMultiplier: return 40
        case .offlineEfficiency: return 25
        }
    }

    mutating func purchase(_ type: BonusType) -> Bool {
        let max = maxLevel(for: type)
        switch type {
        case .coinMultiplier:
            guard coinMultiplierLevel < max else { return false }
            coinMultiplierLevel += 1
        case .xpMultiplier:
            guard xpMultiplierLevel < max else { return false }
            xpMultiplierLevel += 1
        case .startingDistance:
            guard startingDistanceLevel < max else { return false }
            startingDistanceLevel += 1
        case .damageMultiplier:
            guard damageMultiplierLevel < max else { return false }
            damageMultiplierLevel += 1
        case .offlineEfficiency:
            guard offlineEfficiencyLevel < max else { return false }
            offlineEfficiencyLevel += 1
        }
        return true
    }
}

enum BonusType: String, Codable, CaseIterable {
    case coinMultiplier = "Coin Multiplier"
    case xpMultiplier = "XP Multiplier"
    case startingDistance = "Starting Distance"
    case damageMultiplier = "Damage Multiplier"
    case offlineEfficiency = "Offline Efficiency"

    var description: String {
        switch self {
        case .coinMultiplier: return "+5% coin gain per level"
        case .xpMultiplier: return "+5% XP gain per level"
        case .startingDistance: return "+50m starting distance per level"
        case .damageMultiplier: return "+3% damage per level"
        case .offlineEfficiency: return "+2% offline earning rate per level"
        }
    }
}
