import Foundation

let CURRENT_SAVE_VERSION = 1

struct GameState: Codable {
    var saveVersion: Int = CURRENT_SAVE_VERSION

    var createdAt: Date
    var lastSavedAt: Date
    var lastActiveAt: Date

    var coins: Int64 = 0
    var gems: Int64 = 0
    var souls: Int64 = 0
    var totalCoinsEarned: Int64 = 0

    var level: Int = 1
    var currentXP: Double = 0
    var distance: Double = 0
    var totalDistanceAllTime: Double = 0

    var stats: PlayerStats = PlayerStats()
    var unspentStatPoints: Int = 0

    var currentHP: Double = 100
    var maxHP: Double = 100
    var isDead: Bool = false
    var deathCount: Int = 0
    var reviveCooldownEndsAt: Date? = nil

    var activeBoss: Boss? = nil
    var bossesDefeated: Int = 0
    var nextBossDistanceThreshold: Double = 1000

    var equippedItems: [EquipmentSlot: Equipment] = [:]
    var inventory: [Equipment] = []

    var unlockedAbilities: [AbilityID] = []
    var abilityCooldowns: [AbilityID: Date] = [:]
    var autoAbilitiesEnabled: Bool = true

    var prestigeCount: Int = 0
    var permanentBonuses: PermanentBonuses = PermanentBonuses()

    var dailyQuests: [Quest] = []
    var weeklyQuests: [Quest] = []
    var dailyQuestsRefreshAt: Date = Date().addingTimeInterval(86400)
    var weeklyQuestsRefreshAt: Date = Date().addingTimeInterval(7*86400)
    var unlockedAchievements: Set<AchievementID> = []
    var achievementProgress: [AchievementID: Double] = [:]

    var unlockedCosmetics: Set<CosmeticID> = [.defaultCube, .noTrail, .noAura]
    var equippedCosmetics: EquippedCosmetics = EquippedCosmetics()

    var settings: GameSettings = GameSettings()

    var incomingDamageMultiplier: Double = 1.0
    var incomingDamageMultiplierExpiresAt: Date? = nil
    var outgoingDamageMultiplier: Double = 1.0
    var outgoingDamageMultiplierExpiresAt: Date? = nil

    var attackSpeedMultiplier: Double = 1.0
    var attackSpeedMultiplierExpiresAt: Date? = nil

    var vampiricTouchActiveUntil: Date? = nil
    var cubeRageActiveUntil: Date? = nil

    var activeMonster: Monster? = nil

    static func new() -> GameState {
        let now = Date()
        return GameState(createdAt: now, lastSavedAt: now, lastActiveAt: now)
    }
}
