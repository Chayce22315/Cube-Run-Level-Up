import SpriteKit

class ParticleFactory {
    static func coinBurst() -> SKEmitterNode {
        let emitter = SKEmitterNode()
        emitter.particleBirthRate = 50
        emitter.particleLifetime = 0.5
        emitter.particleColor = .yellow
        emitter.particleSpeed = 100
        emitter.particleScale = 0.1
        emitter.particleScaleSpeed = -0.2
        return emitter
    }

    static func levelUpBurst() -> SKEmitterNode {
        let emitter = SKEmitterNode()
        emitter.particleBirthRate = 100
        emitter.particleLifetime = 1.0
        emitter.particleColor = .cyan
        emitter.particleSpeed = 150
        return emitter
    }

    static func prestigeShatter() -> SKEmitterNode {
        let emitter = SKEmitterNode()
        emitter.particleBirthRate = 200
        emitter.particleLifetime = 2.0
        emitter.particleColor = .white
        emitter.particleSpeed = 200
        emitter.particleScale = 0.2
        return emitter
    }
}
