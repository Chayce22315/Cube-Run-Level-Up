import SpriteKit

class BossNode: SKSpriteNode {
    private var hpBar: SKSpriteNode?
    private var phaseLabel: SKLabelNode?

    init() {
        let texture = SKTexture(imageNamed: "boss_01")
        super.init(texture: texture, color: .clear, size: CGSize(width: 80, height: 80))
        setupHPBar()
        setupLabel()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setupHPBar() {
        let bg = SKSpriteNode(color: .darkGray, size: CGSize(width: 70, height: 6))
        bg.position = CGPoint(x: 0, y: 50)
        bg.zPosition = 11
        addChild(bg)

        let bar = SKSpriteNode(color: .red, size: CGSize(width: 70, height: 6))
        bar.position = CGPoint(x: 0, y: 50)
        bar.zPosition = 12
        bar.anchorPoint = CGPoint(x: 0, y: 0.5)
        bar.position = CGPoint(x: -35, y: 50)
        addChild(bar)
        hpBar = bar
    }

    func setupLabel() {
        let label = SKLabelNode(text: "BOSS")
        label.fontSize = 12
        label.fontColor = .white
        label.position = CGPoint(x: 0, y: 60)
        label.zPosition = 13
        addChild(label)
        phaseLabel = label
    }

    func update(hpPercent: Double, phase: Int) {
        hpBar?.xScale = CGFloat(max(0, hpPercent))
        let colors: [SKColor] = [.green, .yellow, .red]
        hpBar?.color = colors[min(phase - 1, 2)]
        phaseLabel?.text = "BOSS - Phase \(phase)"
    }
}
