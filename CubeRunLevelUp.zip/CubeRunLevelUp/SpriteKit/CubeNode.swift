import SpriteKit

class CubeNode: SKSpriteNode {
    enum CubeState { case idle, run, attack, hit, death, revive }

    private var currentState: CubeState = .run
    private var stateTimer: Timer?

    init() {
        let texture = SKTexture(imageNamed: "cube_default")
        super.init(texture: texture, color: .clear, size: CGSize(width: 40, height: 40))
        self.colorBlendFactor = 0
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func update(isDead: Bool, isAttacking: Bool) {
        if isDead && currentState != .death {
            setState(.death)
        } else if !isDead && currentState == .death {
            setState(.revive)
        } else if isAttacking && currentState != .attack {
            setState(.attack)
        } else if !isDead && !isAttacking && currentState != .run {
            setState(.run)
        }
    }

    func setState(_ newState: CubeState) {
        currentState = newState
        switch newState {
        case .idle:
            run(SKAction.colorize(with: .white, colorBlendFactor: 0, duration: 0.1))
        case .run:
            run(SKAction.repeatForever(SKAction.sequence([
                SKAction.moveBy(x: 0, y: 3, duration: 0.15),
                SKAction.moveBy(x: 0, y: -3, duration: 0.15)
            ])))
        case .attack:
            removeAllActions()
            let swing = SKAction.sequence([
                SKAction.rotate(byAngle: .pi/4, duration: 0.1),
                SKAction.rotate(byAngle: -.pi/2, duration: 0.1),
                SKAction.rotate(byAngle: .pi/4, duration: 0.1)
            ])
            run(swing) { [weak self] in self?.setState(.run) }
        case .hit:
            run(SKAction.colorize(with: .red, colorBlendFactor: 0.5, duration: 0.1))
        case .death:
            removeAllActions()
            run(SKAction.sequence([
                SKAction.fadeOut(withDuration: 0.3),
                SKAction.fadeIn(withDuration: 0.3)
            ]))
        case .revive:
            run(SKAction.colorize(with: .green, colorBlendFactor: 0.5, duration: 0.3)) { [weak self] in
                self?.run(SKAction.colorize(with: .white, colorBlendFactor: 0, duration: 0.3))
                self?.setState(.run)
            }
        }
    }

    func triggerAttack() {
        setState(.attack)
    }
}
