import Foundation
import Combine

class SceneBridge: ObservableObject {
    @Published var displayedMonster: Monster? = nil
    @Published var displayedBoss: Boss? = nil
    @Published var playerHPPercent: Double = 1.0
    @Published var isDead: Bool = false
    @Published var distance: Double = 0

    var cancellables = Set<AnyCancellable>()

    func sync(with engine: GameEngine) {
        engine.$state
            .sink { [weak self] state in
                self?.displayedMonster = state.activeMonster
                self?.displayedBoss = state.activeBoss
                self?.playerHPPercent = state.maxHP > 0 ? state.currentHP / state.maxHP : 1.0
                self?.isDead = state.isDead
                self?.distance = state.distance
            }
            .store(in: &cancellables)
    }
}
