import SpriteKit

class MonsterNode: SKSpriteNode {
    private var type: MonsterType = .slime
    private var hpBar: SKSpriteNode?

    init(type: MonsterType) {
        self.type = type
        let texture = SKTexture(imageNamed: "monster_\(type.rawValue)")
        super.init(texture: texture, color: .clear, size: CGSize(width: 35, height: 35))
        setupHPBar()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setupHPBar() {
        let bar = SKSpriteNode(color: .red, size: CGSize(width: 30, height: 4))
        bar.position = CGPoint(x: 0, y: 25)
        bar.zPosition = 11
        addChild(bar)
        hpBar = bar
    }

    func update(type: MonsterType, hpPercent: Double) {
        if self.type != type {
            self.type = type
            self.texture = SKTexture(imageNamed: "monster_\(type.rawValue)")
        }
        hpBar?.xScale = CGFloat(max(0, hpPercent))
    }
}
