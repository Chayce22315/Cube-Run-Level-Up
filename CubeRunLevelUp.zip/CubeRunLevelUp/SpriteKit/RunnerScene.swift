import SpriteKit
import SwiftUI
import Combine

class RunnerScene: SKScene {
    var engine: GameEngine?
    var bridge: SceneBridge?

    private var cubeNode: CubeNode?
    private var monsterNode: MonsterNode?
    private var bossNode: BossNode?
    private var groundNode: SKNode?
    private var backgroundLayers: [SKNode] = []
    private var parallaxSpeeds: [CGFloat] = [0.2, 0.5, 1.0]

    private var lastUpdateTime: TimeInterval = 0
    private var distanceAccumulator: CGFloat = 0

    override func didMove(to view: SKView) {
        self.anchorPoint = CGPoint(x: 0, y: 0)
        self.scaleMode = .aspectFill
        setupBackground()
        setupGround()
        setupCube()

        bridge?.$displayedMonster
            .sink { [weak self] monster in
                self?.updateMonster(monster)
            }
            .store(in: &bridge!.cancellables)

        bridge?.$displayedBoss
            .sink { [weak self] boss in
                self?.updateBoss(boss)
            }
            .store(in: &bridge!.cancellables)
    }

    func setupBackground() {
        for i in 0..<3 {
            let layer = SKNode()
            layer.position = CGPoint(x: 0, y: 0)
            let color = [SKColor.darkGray, SKColor.gray, SKColor.lightGray][i]
            let bg = SKSpriteNode(color: color, size: CGSize(width: size.width, height: size.height))
            bg.position = CGPoint(x: size.width/2, y: size.height/2)
            bg.zPosition = CGFloat(-10 + i)
            layer.addChild(bg)
            addChild(layer)
            backgroundLayers.append(layer)
        }
    }

    func setupGround() {
        let ground = SKSpriteNode(color: .brown, size: CGSize(width: size.width * 2, height: 60))
        ground.position = CGPoint(x: size.width, y: 30)
        ground.zPosition = 1
        addChild(ground)
        groundNode = ground
    }

    func setupCube() {
        let cube = CubeNode()
        cube.position = CGPoint(x: 100, y: 100)
        cube.zPosition = 10
        addChild(cube)
        cubeNode = cube
    }

    func updateMonster(_ monster: Monster?) {
        if let monster = monster {
            if monsterNode == nil {
                let node = MonsterNode(type: monster.type)
                node.position = CGPoint(x: size.width + 40, y: 100)
                node.zPosition = 10
                addChild(node)
                monsterNode = node
            }
            monsterNode?.update(type: monster.type, hpPercent: monster.currentHP / monster.maxHP)
        } else {
            monsterNode?.removeFromParent()
            monsterNode = nil
        }
    }

    func updateBoss(_ boss: Boss?) {
        if let boss = boss {
            if bossNode == nil {
                let node = BossNode()
                node.position = CGPoint(x: size.width * 0.7, y: 120)
                node.zPosition = 10
                addChild(node)
                bossNode = node
            }
            bossNode?.update(hpPercent: boss.currentHP / boss.maxHP, phase: boss.phase)
        } else {
            bossNode?.removeFromParent()
            bossNode = nil
        }
    }

    override func update(_ currentTime: TimeInterval) {
        guard let engine = engine else { return }

        let delta = currentTime - lastUpdateTime
        lastUpdateTime = currentTime

        if !engine.state.isDead && engine.state.activeBoss == nil {
            let speed = CGFloat(4.0 * (1 + Double(engine.effectiveStat(.agility)) * 0.01))
            distanceAccumulator += speed * CGFloat(delta)

            for (i, layer) in backgroundLayers.enumerated() {
                layer.position.x -= speed * parallaxSpeeds[i] * CGFloat(delta) * 10
                if layer.position.x < -size.width {
                    layer.position.x += size.width
                }
            }

            groundNode?.position.x -= speed * CGFloat(delta) * 10
            if (groundNode?.position.x ?? 0) < 0 {
                groundNode?.position.x += size.width
            }

            monsterNode?.position.x -= speed * CGFloat(delta) * 10
            if let mPos = monsterNode?.position.x, mPos < -50 {
                monsterNode?.removeFromParent()
                monsterNode = nil
            }
        }

        cubeNode?.update(isDead: engine.state.isDead, isAttacking: false)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)

        if cubeNode?.contains(location) == true {
            engine?.manualAttack()
            cubeNode?.triggerAttack()
        }
    }
}
