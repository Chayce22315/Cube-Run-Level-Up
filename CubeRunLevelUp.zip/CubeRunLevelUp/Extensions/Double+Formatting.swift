import Foundation

extension Double {
    func abbreviated() -> String {
        let absValue = abs(self)
        let suffixes = ["", "K", "M", "B", "T", "Qa", "Qi"]
        var value = absValue
        var index = 0
        while value >= 1000 && index < suffixes.count - 1 {
            value /= 1000
            index += 1
        }
        let formatter = NumberFormatter()
        formatter.maximumFractionDigits = index == 0 ? 0 : 1
        formatter.minimumFractionDigits = 0
        let numStr = formatter.string(from: NSNumber(value: value)) ?? "\(value)"
        return "\(numStr)\(suffixes[index])"
    }
}

extension Int64 {
    func abbreviated() -> String {
        Double(self).abbreviated()
    }
}
